# CK-Agent Platform v0.4 Architecture

**Sense** → provenance consensus → world model → regime detection → identity discrepancy persistence → IRG / Governor → **goal hierarchy** → **ethical feasibility** → **learned causal action model** → **multi-step counterfactual simulation** → preferred future → action → observed outcome → causal-model update → episodic/semantic memory → explanatory audit → repeat.

## Authority boundaries
- Constitution: non-negotiable constraints.
- Identity: slow structural history; planner has no write authority.
- Goals: desired outcomes, reweighted faster than identity.
- Ethics: hard feasibility filter before utility comparison.
- Causal action model: learns effects of controlled interventions.
- Planner: searches bounded future sequences.
- Explanation: records why the selected future outranked the nearest permitted alternative.

The environment is still synthetic, the action set is small, the horizon is short, and the causal model is linear. v0.4 establishes testable model-based agency architecture, not final general agency.
