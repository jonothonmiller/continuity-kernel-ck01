# CK-Agent v0.4 Release Notes

## Added
- `GoalHierarchy`
- `AgencyEthics`
- `CausalActionModel`
- `ModelBasedPlanner`
- `ModelBasedAgency`
- `AgencyDecision`
- online intervention-effect learning
- bounded multi-step future simulation
- counterfactual preference explanations
- knowledge-state experiments and delayed-reward profiles
- persistent causal-model state across authenticated restarts

## Compatibility
Agency is opt-in. All fourteen v0.3 scientific experiments remain exactly compatible with the frozen v0.3 baseline.

## Non-claims
The learned model is an interventional action-effect model in a controlled synthetic environment. It is not a general causal-discovery engine, a model of human cognition, or evidence of consciousness.
