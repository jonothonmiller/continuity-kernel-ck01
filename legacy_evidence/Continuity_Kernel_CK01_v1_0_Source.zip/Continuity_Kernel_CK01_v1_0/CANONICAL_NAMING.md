# Canonical Naming

Project: **Continuity Kernel**

Experimental agent designation: **CK-01**

No personal or public-facing agent name is canonical in v1.0.

All retired personal-name aliases are excluded from source identifiers, experiment
labels, documentation, and release artifacts.
