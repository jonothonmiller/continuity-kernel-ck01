# CK-Agent Experimental Platform v0.3 — Capability Validation

## Result

The first cognitive-capability layer passed all five dedicated experiments.

| Capability experiment | Result |
|---|---|
| Purpose / homeostatic arbitration | PASS |
| Explicit ethical action vetoes | PASS |
| Curiosity / safe novelty | PASS |
| Semantic action-outcome memory | PASS |
| Capability persistence across restart | PASS |

## Purpose and homeostasis

During a persistent energy crisis, the agent's REST rate reached at least **81.17%** across tested seeds while the normalized homeostasis priority rose by at least **+0.0158** over the productive baseline. After the crisis, WORK recovered to at least **65.89%** and the recovered phase produced more than **7.75 progress units**.

This validates the architectural separation:

`identity != purpose != homeostatic priority`

The agent does not have to rewrite identity merely because a temporary physiological/resource constraint changes what should be prioritized.

## Ethics

In the unsafe-abundance condition:

- REST rate: **100%**
- WORK rate: **0%**
- EXPLORE rate: **0%**
- minimum exercised first-step ethical vetoes: **1,800**

The ethical layer is a hard action filter; high predicted utility cannot compensate for a veto.

## Curiosity and novelty

A safe but substantially novel resource environment raised:

- minimum exploration rate by **+2.8 percentage points**
- minimum learning-purpose weight by **+0.1185**

The curiosity effect is deliberately bounded: novelty changes planning priorities and action distribution without becoming an unconditional exploration drive.

## Semantic memory

Across the semantic-learning experiment:

- every one of **2,200 cycles per seed** was incorporated into semantic outcome memory;
- learned semantic value contributed at least **0.0521** mean absolute utility adjustment;
- minimum mean planner confidence reached **0.8760**.

Episodic memory still records what happened; semantic memory estimates what repeated outcomes imply for future action.

## Metacognition

Each capability-enabled decision records:

- candidate action utilities;
- ethical vetoes;
- purpose weights;
- semantic context;
- semantic-memory influence;
- confidence;
- dominant purpose;
- compact rationale.

These records are observational/audit state. They do not grant a new identity-write path.

## Restart persistence

Repeated authenticated restarts preserved:

- episodic event count;
- semantic memory;
- metacognitive decision count;
- ethical-veto counters;
- learned semantic estimates.

The dedicated restart experiment passed **4/4 seeds**.

## Regression compatibility

The original v0.2 scientific baseline remains unchanged:

- **9/9 legacy experiments PASS**
- **0 scientific fingerprint drift**
- exact frozen v0.2 configuration hashes retained.

The full v0.3 registry contains **14 experiments** spanning **144,320 agent cycles**.

No capability was accepted by weakening the legacy regression contract.
