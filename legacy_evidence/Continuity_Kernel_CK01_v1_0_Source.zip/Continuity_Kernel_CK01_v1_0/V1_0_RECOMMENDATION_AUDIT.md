# CK-01 v1.0 Recommendation Audit

This release implements the major recommendations identified during the
pre-v1 validation program.

| Recommendation | v1.0 status |
|---|---|
| Freeze mature security/runtime interfaces | Implemented; legacy runtime/config byte-identical |
| Explicit EvidenceClaim / ProvenanceRecord semantics | Implemented |
| Independent outcome adjudication | Implemented |
| Temporal IRG state machine | Implemented |
| H0/H1/H2 competing hypotheses | Implemented |
| Richer full-dynamics shadow | Implemented |
| Durable event sourcing / audit chain | Implemented |
| Registry/key governance and revocation | Integrated reference implementation |
| Bounded autonomous subordinate goals | Implemented |
| Counterfactual revision rollback | Implemented |
| Real-world sensor provenance interface | Implemented |
| Formal verification strengthening | Bounded IRG model checking added |
| Persistent-agent longitudinal validation | 8,000-cycle v1 experiment PASS |
| Production empirical calibration | **Still external / not honestly closable synthetically** |
| Hardware-backed production key custody | **Deployment requirement** |
| General learned semantic grounding | **Future research; current semantics partly engineered** |
| Global mathematical proof | **Not complete** |

## Original-goal fidelity

The release keeps the original design constraints:

- history matters, but individual events cannot overwrite the self;
- memory is not identity;
- identity is slower than ordinary learning;
- ethics is not reducible to affect or utility;
- purpose is distinct from identity;
- self-preservation is bounded and subordinate to constitution / human authority;
- recovery preserves autobiographical continuity rather than deleting experience;
- disagreement among subsystems is expected and arbitrated rather than forced into unanimity;
- evidence acceptance does not itself authorize an identity write;
- mature identity can revise when persistent reality genuinely contradicts it;
- all identity revision remains bounded, auditable, and reversible.
