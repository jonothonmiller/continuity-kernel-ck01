# CK-Agent v0.3 Release Notes

## Added
- `CapabilitySystem`
- `PurposeEngine`
- `EthicsEngine`
- `CounterfactualPlanner`
- `SemanticMemory`
- per-decision metacognitive audit records
- optional phase energy overrides and exogenous energy drain
- capability-specific semantic validators
- capability restart-state verification
- v0.3 golden regression baseline

## Compatibility
Capabilities are opt-in. With capabilities disabled, the v0.2 policy and scientific outputs remain exactly compatible with the frozen v0.2 baseline.

## Experimental caution
The capability modules are computational hypotheses implemented for controlled testing. Purpose weights, semantic context bins, planning equations, and thresholds remain synthetic/reference mechanisms rather than empirically validated cognitive constants.
