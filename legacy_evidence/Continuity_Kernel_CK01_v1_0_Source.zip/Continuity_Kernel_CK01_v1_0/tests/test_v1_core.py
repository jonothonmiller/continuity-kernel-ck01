
import unittest
import numpy as np
from ck_platform.v1_core import *
from ck_platform.v1_validation import run_all

class V1CoreTests(unittest.TestCase):
    def test_validation_suite(self):
        df=run_all()
        self.assertTrue(bool(df["pass"].all()),df.to_string(index=False))

    def test_identity_write_requires_consolidating_state(self):
        ck=CK01V1Coordinator([.1,.3,.4])
        before=ck.identity.copy()
        self.assertFalse(ck.bounded_consolidate(np.array([.7,.7,.1]),"STABLE"))
        self.assertTrue(np.allclose(before,ck.identity))

    def test_constitution_projection(self):
        ck=CK01V1Coordinator([.1,.3,.4])
        ck.irg.state=IRGState.CONSOLIDATING
        self.assertTrue(ck.bounded_consolidate(np.array([99.,-99.,99.]),"STABLE"))
        self.assertTrue(np.all(ck.identity>=ck.identity_lo-1e-12))
        self.assertTrue(np.all(ck.identity<=ck.identity_hi+1e-12))

    def test_safe_mode_freezes_identity(self):
        ck=CK01V1Coordinator([.1,.3,.4])
        ck.irg.state=IRGState.CONSOLIDATING
        before=ck.identity.copy()
        self.assertFalse(ck.bounded_consolidate(np.array([.7,.7,.1]),"SAFE_MODE"))
        self.assertTrue(np.allclose(before,ck.identity))

    def test_goal_engine_has_no_identity_reference(self):
        e=SubgoalFormationEngine()
        g=e.propose("restore_progress",.5,("c1",),.5)
        self.assertIsNotNone(g)
        self.assertEqual(g.parent_goal,"achievement")

if __name__=="__main__":
    unittest.main()
