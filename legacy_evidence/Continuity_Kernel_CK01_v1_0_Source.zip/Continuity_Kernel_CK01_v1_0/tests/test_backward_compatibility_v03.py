import json,unittest
from pathlib import Path
from ck_platform.config import load_config
class V03Compatibility(unittest.TestCase):
    def test_v03_config_hashes_match_golden(self):
        root=Path(__file__).resolve().parents[1]
        gold=json.loads((root/'registry'/'golden_baseline_v0_3.json').read_text())
        expected={x['experiment']:x['config_sha256'] for x in gold['experiments']}
        reg=json.loads((root/'registry'/'legacy_v0_3.json').read_text())
        for item in reg['experiments']:
            cfg=load_config(root/'configs'/f"{item['name']}.json")
            self.assertEqual(cfg.canonical_hash(),expected[item['name']],item['name'])
if __name__=='__main__': unittest.main()
