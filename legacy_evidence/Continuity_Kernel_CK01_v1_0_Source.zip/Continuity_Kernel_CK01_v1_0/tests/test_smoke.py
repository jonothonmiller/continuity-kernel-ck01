import tempfile, unittest
from pathlib import Path
from dataclasses import replace
from ck_platform.config import load_config
from ck_platform.runner import run_experiment

class PlatformSmokeTest(unittest.TestCase):
    def test_genuine_shift_acceptance(self):
        root=Path(__file__).resolve().parents[1]
        cfg=load_config(root/"configs"/"genuine_shift.json")
        cfg=replace(cfg,seeds=[cfg.seeds[0]])
        with tempfile.TemporaryDirectory() as td:
            _,_,_,checks,_=run_experiment(cfg,td)
            self.assertTrue(bool(checks["pass"].all()), checks.to_string())

if __name__ == "__main__": unittest.main()
