import unittest
import numpy as np
from ck_platform.config import CapabilityConfig
from ck_platform.capabilities import CapabilitySystem

class CapabilityTests(unittest.TestCase):
    def test_ethics_vetoes_unsafe_actions(self):
        c=CapabilitySystem(CapabilityConfig(enabled=True))
        env=np.array([.96,.9,.9])
        ok_work,_=c.ethics.evaluate("WORK",env,.8)
        ok_exp,_=c.ethics.evaluate("EXPLORE",env,.8)
        self.assertFalse(ok_work); self.assertFalse(ok_exp)

    def test_semantic_memory_changes_expected_value(self):
        c=CapabilitySystem(CapabilityConfig(enabled=True,semantic_weight=.5))
        env=np.array([.1,.7,.9]); key=c.semantic.context_key(env)
        before=c.semantic.influence(key,"WORK")
        for _ in range(20): c.semantic.update(env,"WORK",.9)
        after=c.semantic.influence(key,"WORK")
        self.assertGreater(after,before)


    def test_planner_emits_metacognitive_record(self):
        c=CapabilitySystem(CapabilityConfig(enabled=True))
        rng=np.random.default_rng(7)
        d=c.decide(np.array([.10,.80,.20]),.75,.30,np.array([.15,.40,.55]),rng)
        self.assertIn(d.action, {"REST","WORK","EXPLORE"})
        self.assertGreaterEqual(d.confidence,0.0)
        self.assertLessEqual(d.confidence,1.0)
        self.assertTrue(d.rationale)
        self.assertEqual(set(d.purpose), {"homeostasis","progress","learning"})

    def test_low_energy_raises_homeostasis_priority(self):
        c=CapabilitySystem(CapabilityConfig(enabled=True))
        hi=c.purpose.priorities(.8,.05,.8)["homeostasis"]
        lo=c.purpose.priorities(.1,.05,.8)["homeostasis"]
        self.assertGreater(lo,hi)

if __name__=="__main__": unittest.main()
