
import unittest, base64, os, time
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization
from ck_platform.grounding import SensorGroundingAdapter
from ck_platform.key_governance import (
    AdminIdentity, AdminQuorum, KeyGovernance, SignedEnvelope,
    SecureStateCipher, canonical_json, b64e
)

def pubb(priv):
    return priv.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw
    )

class V1SecurityGroundingTests(unittest.TestCase):
    def test_sensor_grounding_provenance(self):
        a=SensorGroundingAdapter("sensor-1","device-1","cal-v1")
        r=a.record("2026-09-04T12:00:00-07:00","hazard",.42,"normalized",
                   reference_value=.40,reference_unit="normalized")
        self.assertEqual(r.sequence,1)
        self.assertEqual(r.quality,"VALID")
        self.assertEqual(len(r.canonical_hash()),64)

    def test_dual_control_registry_manifest(self):
        priv={f"a{i}":Ed25519PrivateKey.generate() for i in range(3)}
        admins=[AdminIdentity(k,b64e(pubb(v)),"admin") for k,v in priv.items()]
        q=AdminQuorum(admins,2)
        payload={"type":"registry_manifest","epoch":1,"registry_hash":"abc"}
        sigs={k:b64e(priv[k].sign(canonical_json(payload))) for k in ("a0","a1")}
        env=SignedEnvelope(payload,sigs)
        gov=KeyGovernance(q)
        gov.install_registry_manifest(env)
        self.assertEqual(gov.registry_hash,"abc")

    def test_aes_gcm_state_tamper_rejection(self):
        key=os.urandom(32)
        blob=SecureStateCipher.encrypt({"identity":[.1,.2,.3]},key,"k1","ck01")
        self.assertEqual(SecureStateCipher.decrypt(blob,key)["identity"],[.1,.2,.3])
        bad=dict(blob)
        raw=bytearray(base64.b64decode(bad["ciphertext_b64"]))
        raw[0]^=1
        bad["ciphertext_b64"]=base64.b64encode(bytes(raw)).decode()
        with self.assertRaises(Exception):
            SecureStateCipher.decrypt(bad,key)

if __name__=="__main__":
    unittest.main()
