import hashlib, tempfile, unittest
from pathlib import Path
from dataclasses import replace
from ck_platform.config import load_config
from ck_platform.runner import run_experiment

class ReproducibilityTest(unittest.TestCase):
    def test_same_seed_same_scientific_outputs(self):
        root=Path(__file__).resolve().parents[1]
        cfg=load_config(root/"configs"/"stable_life.json")
        cfg=replace(cfg,seeds=[2100])
        with tempfile.TemporaryDirectory() as a, tempfile.TemporaryDirectory() as b:
            run_experiment(cfg,a); run_experiment(cfg,b)
            for name in ["summary.csv","trace.csv","phase_metrics.csv","acceptance.csv"]:
                x=Path(a,name).read_bytes(); y=Path(b,name).read_bytes()
                self.assertEqual(hashlib.sha256(x).hexdigest(),hashlib.sha256(y).hexdigest(),name)

if __name__ == "__main__": unittest.main()

class CapabilityReproducibilityTest(unittest.TestCase):
    def test_capability_same_seed_same_scientific_outputs(self):
        root=Path(__file__).resolve().parents[1]
        cfg=load_config(root/'configs'/'capability_curiosity.json')
        cfg=replace(cfg,seeds=[cfg.seeds[0]])
        with tempfile.TemporaryDirectory() as a, tempfile.TemporaryDirectory() as b:
            run_experiment(cfg,a); run_experiment(cfg,b)
            for name in ['summary.csv','trace.csv','phase_metrics.csv','acceptance.csv']:
                x=Path(a,name).read_bytes(); y=Path(b,name).read_bytes()
                self.assertEqual(hashlib.sha256(x).hexdigest(),hashlib.sha256(y).hexdigest(),name)


class AgencyReproducibilityTest(unittest.TestCase):
    def test_agency_same_seed_same_scientific_outputs(self):
        root=Path(__file__).resolve().parents[1]
        cfg=load_config(root/'configs'/'agency_explanation_grounding.json')
        cfg=replace(cfg,seeds=[cfg.seeds[0]])
        with tempfile.TemporaryDirectory() as a, tempfile.TemporaryDirectory() as b:
            run_experiment(cfg,a); run_experiment(cfg,b)
            for name in ['summary.csv','trace.csv','phase_metrics.csv','acceptance.csv']:
                x=Path(a,name).read_bytes(); y=Path(b,name).read_bytes()
                self.assertEqual(hashlib.sha256(x).hexdigest(),hashlib.sha256(y).hexdigest(),name)
