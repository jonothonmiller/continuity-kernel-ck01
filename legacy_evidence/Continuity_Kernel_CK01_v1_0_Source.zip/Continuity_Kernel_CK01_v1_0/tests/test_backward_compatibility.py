import json, unittest
from pathlib import Path
from ck_platform.config import load_config

class BackwardCompatibilityTest(unittest.TestCase):
    def test_v02_config_hashes_match_golden(self):
        root=Path(__file__).resolve().parents[1]
        baseline=json.loads((root/"registry"/"golden_baseline_v0_2.json").read_text())
        expected={x["experiment"]:x["config_sha256"] for x in baseline["experiments"]}
        registry=json.loads((root/"registry"/"legacy_v0_2.json").read_text())
        for item in registry["experiments"]:
            cfg=load_config(root/"configs"/(item["name"]+".json"))
            self.assertEqual(cfg.canonical_hash(),expected[item["name"]],item["name"])
if __name__=="__main__": unittest.main()
