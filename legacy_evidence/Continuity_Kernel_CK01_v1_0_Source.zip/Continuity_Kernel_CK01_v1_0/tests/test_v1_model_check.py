
import unittest
from ck_platform.v1_model_check import check

class V1ModelCheckTests(unittest.TestCase):
    def test_temporal_irg_safety_model(self):
        result=check(depth=7)
        self.assertTrue(result["pass"],result)

if __name__=="__main__":
    unittest.main()
