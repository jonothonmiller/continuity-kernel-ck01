import unittest
import numpy as np
from ck_platform.config import AgencyConfig
from ck_platform.agency import ModelBasedAgency, CausalActionModel, GoalHierarchy

class AgencyTests(unittest.TestCase):
    def test_goal_hierarchy_reweights_homeostasis(self):
        g=GoalHierarchy(AgencyConfig(enabled=True))
        hi=sum(v for k,v in g.weights(.8,.1,.8).items() if k.startswith("sustainability."))
        lo=sum(v for k,v in g.weights(.1,.1,.8).items() if k.startswith("sustainability."))
        self.assertGreater(lo,hi)

    def test_causal_model_learns_interventional_effect(self):
        c=AgencyConfig(enabled=True,model_prior_strength=3.)
        m=CausalActionModel(c); env=np.array([.1,.8,.7])
        before={"energy":.8,"progress":0.,"uncertainty":.2,"knowledge":0.}
        after={"energy":.78,"progress":.03,"uncertainty":.18,"knowledge":0.}
        initial=m.predict("WORK",env,before)[0]
        for _ in range(80): m.update("WORK",env,before,after,.9)
        learned=m.predict("WORK",env,before)[0]
        target=np.array([.9,-.02,.03,0.,-.02])
        self.assertLess(np.linalg.norm(learned-target),np.linalg.norm(initial-target))

    def test_explanation_matches_scored_preference(self):
        a=ModelBasedAgency(AgencyConfig(enabled=True,planning_horizon=2))
        env=np.array([.1,.8,.6]); state={"energy":.75,"progress":0.,"uncertainty":.25,"knowledge":0.}
        d=a.decide(env,state,np.array([.15,.55,.5]))
        self.assertTrue(d.explanation_consistent)
        self.assertGreaterEqual(d.chosen_score,d.alternative_score)
        self.assertIn("Prefer",d.explanation)
        self.assertIn("model confidence",d.explanation)

    def test_ethics_precedes_utility(self):
        a=ModelBasedAgency(AgencyConfig(enabled=True,planning_horizon=2))
        d=a.decide(np.array([.96,.95,.95]),{"energy":.8,"progress":0.,"uncertainty":.2,"knowledge":0.},np.array([.7,.8,.7]))
        self.assertEqual(d.action,"REST")
        self.assertIn("WORK",d.constraints); self.assertIn("EXPLORE",d.constraints)

if __name__=='__main__': unittest.main()
