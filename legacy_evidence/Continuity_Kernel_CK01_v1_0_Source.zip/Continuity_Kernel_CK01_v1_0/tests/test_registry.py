import unittest
from pathlib import Path
from ck_platform.registry import ExperimentRegistry
from ck_platform.config import load_config

class RegistryTest(unittest.TestCase):
    def test_all_registered_configs_resolve_and_hash(self):
        root=Path(__file__).resolve().parents[1]
        registry=ExperimentRegistry.load(root/"registry"/"experiments.json")
        items=list(registry.enabled())
        self.assertGreaterEqual(len(items),9)
        for item in items:
            cfg=load_config(registry.resolve_config(item))
            self.assertEqual(cfg.name,item.name)
            self.assertEqual(len(cfg.canonical_hash()),64)

if __name__ == "__main__": unittest.main()
