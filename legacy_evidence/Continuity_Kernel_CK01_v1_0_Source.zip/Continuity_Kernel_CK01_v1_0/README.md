# Continuity Kernel — CK-01 v1.0

CK-01 v1.0 is the first integrated experimental reference release of the
Continuity Kernel.

The project investigates whether an artificial system can have a persistent,
history-dependent self-model whose ordinary learning is fast, whose identity
changes slowly, and whose constitutional constraints are not writable by
ordinary experience.

## Central rule

> Experience may propose change. Evidence may reinforce change. Reflection may
> approve change. Homeostasis limits change. Continuity determines what becomes
> part of the self.

## Plasticity hierarchy

**State → Adaptation → Identity → Constitution**

## Identity revision

**Evidence → Temporal IRG → Competing Hypotheses → Full Shadow → Governor →
Bounded Consolidation → Counterfactual Review → Retain/Rollback**

## Validation

- 10/10 new v1.0 mechanism experiments PASS
- 24/24 unit/security/compatibility tests PASS
- 524,288 bounded temporal-IRG transitions checked with 0 violations
- 8,000-cycle longitudinal continuity test PASS
- 35/35 inherited runtime/config files byte-identical to the frozen v0.4 tree

See:
- `V1_0_ARCHITECTURE.md`
- `V1_0_VALIDATION_REPORT.md`
- `V1_0_RECOMMENDATION_AUDIT.md`
- `V1_0_RELEASE_NOTES.md`

This is a research architecture, not a claim of consciousness or a validated
model of human cognition.
