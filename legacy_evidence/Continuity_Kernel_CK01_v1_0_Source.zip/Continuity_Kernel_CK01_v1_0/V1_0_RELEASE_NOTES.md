# Continuity Kernel — CK-01 v1.0 Release Notes

## Milestone progression

### v0.5 — Bounded goal formation
Added subordinate-goal proposal, capacity limits, parent-purpose binding, and
explicit prohibition of safety/constitutional bypass goals.

### v0.6 — Evidence and temporal revision
Added typed evidence claims, provenance parentage, independent outcome
certificates, append-only audit ledger, and the temporal IRG state machine.

### v0.7 — Epistemic revision discipline
Added explicit competition among world-model-only, adaptation, and identity
hypotheses with complexity and identity-change penalties.

### v0.8 — Full-dynamics shadow
Replaced simple target-distance shadow logic with a comparison incorporating
prediction, homeostasis, ethics, goal coherence, and stability margin.

### v0.9 — Recovery and governance
Added counterfactual revision rollback, event-sourced continuity,
authenticated recovery, key-governance integration, and physical-sensor
provenance grounding.

### v1.0 — Integrated CK-01 reference architecture
Integrated the above mechanisms around the existing persistent identity,
semantic memory, causal action learning, purpose, ethics, planning,
metacognition, governor, provenance, and bounded identity machinery.

## v1.0 validation
- 10/10 new mechanism experiments PASS
- 24/24 unit/security/compatibility tests PASS
- 524,288 bounded IRG transitions checked, 0 violations
- 8,000-cycle longitudinal continuity experiment PASS
- 35/35 pre-existing runtime/config files byte-identical to v0.4
- canonical project designation: Continuity Kernel / CK-01
