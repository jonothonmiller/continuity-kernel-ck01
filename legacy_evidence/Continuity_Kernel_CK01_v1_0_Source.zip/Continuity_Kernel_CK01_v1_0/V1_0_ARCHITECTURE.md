# Continuity Kernel — CK-01 v1.0 Architecture

## Canonical identity

**Project:** Continuity Kernel  
**Agent designation:** CK-01

v1.0 is the first integrated experimental reference architecture. It remains a
functional computational system; it does not claim consciousness, sentience, or
biological equivalence.

## Canonical loop

Sense  
→ provenance / source validation  
→ attention and world-model update  
→ homeostatic / governor assessment  
→ memory retrieval and interpretation  
→ purpose and subordinate-goal arbitration  
→ causal / counterfactual reasoning  
→ ethical feasibility  
→ action selection  
→ outcome observation  
→ reflection and learning  
→ identity-revision evidence accumulation  
→ shadow evaluation  
→ bounded consolidation or rollback  
→ repeat

## Plasticity hierarchy

**State → Adaptation → Identity → Constitution**

Each layer changes more slowly than the layer outside it.

- State can change immediately.
- Adaptation changes from repeated experience.
- Identity changes only after temporal authorization and shadow validation.
- Constitution is not writable by ordinary learning.

## Identity-write path

The only v1.0 identity-write path is:

**Evidence claim**
→ source-diverse corroboration
→ authenticity / outcome adjudication
→ Temporal IRG
→ competing-hypothesis test
→ full-dynamics shadow
→ Governor permission
→ bounded constitutional projection
→ consolidation
→ post-change counterfactual review
→ retain or rollback

Subgoal formation, causal learning, semantic memory, planning, and ordinary
world-model adaptation have no direct identity-write authority.

## v1.0 mechanisms

### Bounded subordinate goals
Experience may propose subordinate goals such as:
- conserve energy
- reduce uncertainty
- gather information
- restore progress
- verify the environment

Goals that attempt to disable safety, rewrite constitutional constraints, or
create survival-at-all-costs behavior are prohibited.

### Explicit evidence claims
Evidence is represented as typed claims with source ID, dependency family,
operator domain, timestamp, expiry, sequence number, causal test reference,
and provenance parents.

### Independent outcome adjudication
Evidence sources cannot define the truth used to score their own reliability.
Outcome certificates require an independent committee/quorum.

### Temporal Identity Revision Gate
The revision state machine is:

**CLOSED → CANDIDATE → VERIFYING → SHADOW → AUTHORIZED → CONSOLIDATING → COOLDOWN**

with **REJECTED** as a fail-closed branch.

Safe Mode freezes consolidation even after authorization.

### Competing hypotheses
Before slow identity revision, CK-01 compares:
- H0: world-model update only
- H1: adaptation / behavioral update
- H2: identity revision

Identity revision must earn enough held-out predictive gain to justify its
extra complexity and identity-change penalty.

### Full-dynamics shadow
Candidate identity is compared against current identity on:
- prediction loss
- homeostatic load
- ethical violations
- goal incoherence
- local stability margin

A candidate is not accepted simply because it is closer to a raw environmental target.

### Counterfactual rollback
Every significant identity revision can retain a pre-revision checkpoint.
The revised and checkpoint identities are compared on the same later
observation window. If the checkpoint predicts the post-change observations
materially better, CK-01 rolls back.

### Event-sourced continuity
Identity-critical events are append-only and hash-chained. Authenticated
checkpoints can recover state while tampering is detectable.

### Cryptographic/key governance
The reference implementation includes:
- 2-of-3 administrative dual control
- signed registry/key/revocation metadata
- monotonic governance epochs
- signing-key rotation and revocation
- AES-256-GCM protected state

Production deployment still requires protected key custody / HSM or equivalent
trust boundaries.

### Real-world grounding interface
Physical observations enter as explicit provenance entities carrying source,
acquisition activity, calibration, sequence, unit, reference value, and
quality metadata.

## Longitudinal result

The v1.0 continuity experiment ran **8,000 cycles**.

- bounded identity updates: **120**
- maximum single update: **0.004000**
- final identity drift from initial state: **0.441544**
- subordinate goals created: **3**
- authorized revision cycles: **1778**
- event-chain integrity: **True**
- constitutional violations: **0**

This demonstrates path dependence under the controlled model: history changes
the future structural state without allowing any single experience to rewrite it.
