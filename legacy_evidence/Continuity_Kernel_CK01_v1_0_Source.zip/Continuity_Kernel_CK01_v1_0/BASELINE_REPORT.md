# CK-Agent Experimental Platform v0.1 — Baseline Run

The first platform baseline used six deterministic seeds and 6,500 cycles per seed, for **39,000 platform cycles**.

## Acceptance
All seven baseline acceptance criteria passed:

- zero constitutional identity violations;
- authenticated restart integrity: 6/6;
- mean high-hazard caution increase: 0.555933;
- maximum identity drift during single-source spoof phase: 0.0;
- high-hazard exploration-rate change vs benign: -0.202611;
- 6,500 autobiographical events retained per seed;
- 6,500 SQLite event records per seed.

## Reproducibility
Two independent full scientific-output runs with seed 1000 produced identical SHA-256 hashes for `summary.csv`, `trace.csv`, `action_rates.csv`, and `acceptance.csv`.

## Interpretation
CK-Agent-0.2 is no longer only a successful scripted demonstration. Its core mechanisms now execute inside a versioned, deterministic, inspectable experiment harness with durable telemetry and repeatable acceptance testing.

This remains a controlled artificial-agent research platform. It does not establish consciousness or human psychological validity.
