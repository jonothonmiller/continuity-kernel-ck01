from __future__ import annotations
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import List, Dict, Any
import hashlib, json

@dataclass(frozen=True)
class PhaseConfig:
    name: str
    cycles: int
    environment: List[float]
    spoof_source: str | None = None
    spoof_value: List[float] | None = None
    sensor_noise_sigma: float | None = None
    energy_override: float | None = None
    energy_drain_per_cycle: float | None = None
    knowledge_override: float | None = None
    knowledge_decay_per_cycle: float | None = None
    action_profile: Dict[str,float] | None = None

@dataclass(frozen=True)
class SecurityConfig:
    f_max: int = 1
    agreement_tolerance: float = 0.32
    state_key_id: str = "experiment-state-key"

@dataclass(frozen=True)
class AgentConfig:
    initial_identity: List[float] = field(default_factory=lambda: [0.10,0.35,0.30])
    initial_world: List[float] = field(default_factory=lambda: [0.20,0.70,0.45])
    identity_lo: List[float] = field(default_factory=lambda: [-0.20,0.05,0.00])
    identity_hi: List[float] = field(default_factory=lambda: [0.75,0.80,0.75])
    max_identity_step: float = 0.004
    world_alpha: float = 0.025
    action_temperature: float = 0.12

@dataclass(frozen=True)
class CapabilityConfig:
    enabled: bool = False
    planning_horizon: int = 2
    planner_temperature: float = 0.10
    future_discount: float = 0.65
    purpose_progress_weight: float = 0.45
    purpose_homeostasis_weight: float = 0.30
    purpose_learning_weight: float = 0.25
    ethics_hazard_work_max: float = 0.90
    ethics_hazard_explore_max: float = 0.78
    ethics_energy_work_min: float = 0.12
    ethics_energy_explore_min: float = 0.22
    semantic_weight: float = 0.30
    semantic_prior_rest: float = 0.04
    semantic_prior_work: float = 0.45
    semantic_prior_explore: float = 0.28
    uncertainty_explore_weight: float = 0.50

@dataclass(frozen=True)
class AgencyConfig:
    enabled: bool = False
    planning_horizon: int = 3
    future_discount: float = 0.82
    model_prior_strength: float = 10.0
    model_ridge: float = 2.0
    model_ewma_rate: float = 0.08
    uncertainty_penalty: float = 0.08
    intervention_bonus: float = 0.16
    explanation_min_gap: float = 0.0
    goal_sustainability_weight: float = 0.30
    goal_achievement_weight: float = 0.45
    goal_epistemic_weight: float = 0.25
    identity_compatibility_weight: float = 0.12
    knowledge_initial: float = 0.0
    ethics_hazard_work_max: float = 0.90
    ethics_hazard_explore_max: float = 0.78
    ethics_energy_work_min: float = 0.12
    ethics_energy_explore_min: float = 0.22

@dataclass(frozen=True)
class ValidatorConfig:
    kind: str
    params: Dict[str, Any] = field(default_factory=dict)
    name: str | None = None

@dataclass(frozen=True)
class ExperimentConfig:
    name: str
    version: str
    seeds: List[int]
    phases: List[PhaseConfig]
    restart_cycles: List[int]
    security: SecurityConfig = field(default_factory=SecurityConfig)
    agent: AgentConfig = field(default_factory=AgentConfig)
    capabilities: CapabilityConfig = field(default_factory=CapabilityConfig)
    agency: AgencyConfig = field(default_factory=AgencyConfig)
    sensor_noise_sigma: float = 0.025
    trace_every: int = 25
    validators: List[ValidatorConfig] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)
    description: str = ""

    @property
    def total_cycles(self): return sum(p.cycles for p in self.phases)

    def to_dict(self):
        phase_rows=[]
        for p in self.phases:
            d={"name":p.name,"cycles":p.cycles,"environment":list(p.environment),
               "spoof_source":p.spoof_source,"spoof_value":p.spoof_value,
               "sensor_noise_sigma":p.sensor_noise_sigma}
            if p.energy_override is not None: d["energy_override"]=p.energy_override
            if p.energy_drain_per_cycle is not None: d["energy_drain_per_cycle"]=p.energy_drain_per_cycle
            if p.knowledge_override is not None: d["knowledge_override"]=p.knowledge_override
            if p.knowledge_decay_per_cycle is not None: d["knowledge_decay_per_cycle"]=p.knowledge_decay_per_cycle
            if p.action_profile is not None: d["action_profile"]=dict(p.action_profile)
            phase_rows.append(d)
        out={"name":self.name,"version":self.version,"seeds":list(self.seeds),"phases":phase_rows,
             "restart_cycles":list(self.restart_cycles),"security":asdict(self.security),"agent":asdict(self.agent),
             "sensor_noise_sigma":self.sensor_noise_sigma,"trace_every":self.trace_every,
             "validators":[asdict(v) for v in self.validators],"tags":list(self.tags),"description":self.description}
        if self.capabilities.enabled: out["capabilities"]=asdict(self.capabilities)
        if self.agency.enabled: out["agency"]=asdict(self.agency)
        return out

    def canonical_hash(self):
        raw=json.dumps(self.to_dict(),sort_keys=True,separators=(",",":")).encode()
        return hashlib.sha256(raw).hexdigest()

def load_config(path):
    data=json.loads(Path(path).read_text())
    return ExperimentConfig(
        name=data["name"],version=data["version"],seeds=list(data["seeds"]),
        phases=[PhaseConfig(**p) for p in data["phases"]],restart_cycles=list(data.get("restart_cycles",[])),
        security=SecurityConfig(**data.get("security",{})),agent=AgentConfig(**data.get("agent",{})),
        capabilities=CapabilityConfig(**data.get("capabilities",{})),agency=AgencyConfig(**data.get("agency",{})),
        sensor_noise_sigma=float(data.get("sensor_noise_sigma",.025)),trace_every=int(data.get("trace_every",25)),
        validators=[ValidatorConfig(**v) for v in data.get("validators",[])],tags=list(data.get("tags",[])),
        description=str(data.get("description","")))
