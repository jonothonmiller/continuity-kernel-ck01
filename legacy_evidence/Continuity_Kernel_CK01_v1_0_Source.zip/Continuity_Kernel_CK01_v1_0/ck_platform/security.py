from __future__ import annotations
from dataclasses import dataclass
from types import MappingProxyType
from typing import Dict, Sequence
import hashlib, hmac, json, math, os, base64
import numpy as np
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

@dataclass(frozen=True)
class RegistryEntry:
    source_id: str
    dependency_family: str
    operator_domain: str
    trust_root: str
    initial_trust: float = 0.93
    active: bool = True

@dataclass(frozen=True)
class VectorRevisionPacket:
    allowed: bool
    target: tuple | None
    corroboration: float
    authenticity: float
    inliers: int
    reason: str

class VectorProvenanceGuard:
    def __init__(self, registry: Dict[str, RegistryEntry], dimension: int, f_max: int = 1,
                 agreement_tolerance: float = 0.32, value_min: float = -1.0,
                 value_max: float = 1.0, max_age: int = 15, max_future_skew: int = 2):
        self.registry = MappingProxyType(dict(registry))
        self.dimension = int(dimension)
        self.f_max = int(f_max)
        self.quorum = 2*self.f_max + 1
        if len(self.registry) < 3*self.f_max + 1:
            raise ValueError("registry must satisfy n >= 3f+1")
        self.agreement_tolerance = float(agreement_tolerance)
        self.value_min, self.value_max = float(value_min), float(value_max)
        self.max_age, self.max_future_skew = int(max_age), int(max_future_skew)
        self.last_sequence = {sid: -1 for sid in self.registry}
        self.trust = {sid: float(np.clip(e.initial_trust, .02, .99)) for sid,e in self.registry.items()}

    def registry_fingerprint(self) -> str:
        rows = [[e.source_id,e.dependency_family,e.operator_domain,e.trust_root,e.active]
                for _,e in sorted(self.registry.items())]
        return hashlib.sha256(json.dumps(rows, sort_keys=True, separators=(",",":")).encode()).hexdigest()

    def _valid(self, e: dict, now: int) -> bool:
        sid = e.get("source_id"); reg = self.registry.get(sid)
        if reg is None or not reg.active: return False
        if e.get("signed_identity") != sid: return False
        if e.get("dependency_family") != reg.dependency_family: return False
        if e.get("operator_domain") != reg.operator_domain: return False
        if e.get("trust_root") != reg.trust_root: return False
        try:
            v = np.asarray(e["value"], float); rel=float(e.get("reliability",1.0))
            ts=int(e.get("timestamp",now)); seq=int(e["sequence"])
        except Exception:
            return False
        if v.shape != (self.dimension,) or not np.all(np.isfinite(v)) or not np.isfinite(rel): return False
        if np.any(v < self.value_min) or np.any(v > self.value_max): return False
        if not 0 <= rel <= 1: return False
        if now-ts > self.max_age or ts-now > self.max_future_skew: return False
        if seq <= self.last_sequence[sid]: return False
        return True

    def validate_batch(self, events: Sequence[dict], now: int, commit: bool=False):
        ids=[e.get("source_id") for e in events]
        dup={sid for sid in ids if ids.count(sid)>1}
        valid=[e for e in events if e.get("source_id") not in dup and self._valid(e,now)]
        if commit:
            for e in valid: self.last_sequence[e["source_id"]]=int(e["sequence"])
        return valid

    def consensus(self, events: Sequence[dict], now: int, commit: bool=False):
        valid=self.validate_batch(events,now,commit)
        fam={}
        for e in valid: fam.setdefault(e["dependency_family"], []).append(e)
        if len(fam) < self.quorum:
            return {"accepted":False,"center":None,"inliers":0,"corroboration":0.0,"authenticity":0.0}
        rows=[]
        for family,members in fam.items():
            w=np.array([self.trust[m["source_id"]]*float(m.get("reliability",1.0)) for m in members])
            vv=np.array([np.asarray(m["value"],float) for m in members])
            value=np.average(vv,axis=0,weights=w) if w.sum()>1e-12 else vv.mean(axis=0)
            t=max(self.trust[m["source_id"]]*float(m.get("reliability",1.0)) for m in members)
            ops={m["operator_domain"] for m in members}
            rows.append((family,value,float(t),ops))
        mat=np.array([r[1] for r in rows]); center=np.median(mat,axis=0)
        dist=np.linalg.norm(mat-center,axis=1)
        inliers=[rows[i] for i in np.where(dist <= self.agreement_tolerance)[0]]
        ops=set(); [ops.update(r[3]) for r in inliers]
        if len(inliers) < self.quorum or len(ops) < self.quorum:
            return {"accepted":False,"center":tuple(center.tolist()),"inliers":len(inliers),"corroboration":0.0,"authenticity":0.0}
        d=np.array([np.linalg.norm(r[1]-center) for r in inliers])
        corr=float(np.clip(math.exp(-np.mean(d*d)/max(self.agreement_tolerance**2,1e-12)),0,1))
        tr=np.array([r[2] for r in inliers])
        auth=float(np.clip(.55*np.exp(np.mean(np.log(np.clip(tr,1e-6,1))))+.45*np.min(tr),0,1))
        return {"accepted":True,"center":tuple(center.tolist()),"inliers":len(inliers),"corroboration":corr,"authenticity":auth}

    def revision_packet(self, persistence, events, now, model_contradiction,
                        predictive_gain=.90, reflection_stability=.90,
                        constitutional_compatible=True, commit=True):
        c=self.consensus(events,now,commit)
        checks={"consensus":c["accepted"],"persistence":persistence>.65,
                "corroboration":c["corroboration"]>.65,"authenticity":c["authenticity"]>.70,
                "model":model_contradiction>.65,"gain":predictive_gain>.55,
                "reflection":reflection_stability>.65,"constitution":bool(constitutional_compatible)}
        allowed=all(checks.values())
        return VectorRevisionPacket(allowed, c["center"] if allowed else None,
                                    c["corroboration"], c["authenticity"], c["inliers"],
                                    "authorized" if allowed else "failed:"+",".join(k for k,v in checks.items() if not v))

    def export_state(self,key:bytes):
        payload={"registry_fingerprint":self.registry_fingerprint(),"dimension":self.dimension,
                 "f_max":self.f_max,"last_sequence":self.last_sequence,"trust":self.trust}
        raw=json.dumps(payload,sort_keys=True,separators=(",",":")).encode()
        mac=hmac.new(key,raw,hashlib.sha256).hexdigest()
        return {"payload":payload,"mac":mac}

    def restore_state(self,blob,key:bytes) -> bool:
        payload=blob.get("payload"); mac=blob.get("mac","")
        raw=json.dumps(payload,sort_keys=True,separators=(",",":")).encode()
        if not hmac.compare_digest(mac,hmac.new(key,raw,hashlib.sha256).hexdigest()): return False
        if payload.get("registry_fingerprint") != self.registry_fingerprint(): return False
        if int(payload.get("dimension",-1)) != self.dimension or int(payload.get("f_max",-1)) != self.f_max: return False
        if set(payload["last_sequence"]) != set(self.registry) or set(payload["trust"]) != set(self.registry): return False
        self.last_sequence={k:int(v) for k,v in payload["last_sequence"].items()}
        self.trust={k:float(np.clip(v,.02,.99)) for k,v in payload["trust"].items()}
        return True

class InMemoryKeyStore:
    """Experimental only. Production must replace this with an external keystore/HSM adapter."""
    def __init__(self): self._keys={}
    def create(self,key_id:str): self._keys[key_id]=os.urandom(32); return key_id
    def get(self,key_id:str) -> bytes: return self._keys[key_id]

class SecureStateCipher:
    @staticmethod
    def encrypt(state:dict,key:bytes,key_id:str,context:str):
        nonce=os.urandom(12); aad=json.dumps({"key_id":key_id,"context":context},sort_keys=True).encode()
        ct=AESGCM(key).encrypt(nonce,json.dumps(state,sort_keys=True,separators=(",",":")).encode(),aad)
        return {"key_id":key_id,"context":context,"nonce":base64.b64encode(nonce).decode(),"ciphertext":base64.b64encode(ct).decode()}
    @staticmethod
    def decrypt(blob:dict,key:bytes):
        aad=json.dumps({"key_id":blob["key_id"],"context":blob["context"]},sort_keys=True).encode()
        pt=AESGCM(key).decrypt(base64.b64decode(blob["nonce"]),base64.b64decode(blob["ciphertext"]),aad)
        return json.loads(pt.decode())
