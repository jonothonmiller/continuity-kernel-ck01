from __future__ import annotations
from pathlib import Path
import sqlite3, json

class ExperimentStore:
    def __init__(self,path):
        self.path=Path(path); self.conn=sqlite3.connect(self.path)
        self.conn.execute("""CREATE TABLE IF NOT EXISTS events(
            seed INTEGER, cycle INTEGER, phase TEXT, identity TEXT, world TEXT,
            mode TEXT, action TEXT, reward REAL, residual REAL, authorized INTEGER,
            revised INTEGER, energy REAL, progress REAL, memory_events INTEGER,
            PRIMARY KEY(seed,cycle))""")
        self.conn.execute("""CREATE TABLE IF NOT EXISTS checkpoints(
            seed INTEGER, cycle INTEGER, state_blob TEXT, provenance_blob TEXT,
            PRIMARY KEY(seed,cycle))""")
        self.conn.execute("""CREATE TABLE IF NOT EXISTS agency_decisions(
            seed INTEGER, cycle INTEGER, action TEXT, sequence TEXT, alternative_sequence TEXT,
            chosen_score REAL, alternative_score REAL, preference_gap REAL, model_confidence REAL,
            goal_weights TEXT, goal_contributions TEXT, predicted_final_state TEXT,
            constraints TEXT, explanation TEXT, consistent INTEGER, PRIMARY KEY(seed,cycle))""")
        self.conn.execute("""CREATE TABLE IF NOT EXISTS decisions(
            seed INTEGER, cycle INTEGER, action TEXT, confidence REAL,
            utilities TEXT, vetoes TEXT, purpose TEXT, semantic_context TEXT,
            semantic_influence TEXT, dominant_purpose TEXT, rationale TEXT,
            PRIMARY KEY(seed,cycle))""")
        self.conn.commit()

    def log_event(self,seed,cycle,phase,identity,world,mode,action,reward,residual,authorized,revised,energy,progress,memory_events):
        self.conn.execute("INSERT OR REPLACE INTO events VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (seed,cycle,phase,json.dumps(list(map(float,identity))),json.dumps(list(map(float,world))),mode,action,float(reward),float(residual),
             int(authorized),int(revised),float(energy),float(progress),int(memory_events)))

    def log_decision(self,seed,cycle,decision):
        self.conn.execute("INSERT OR REPLACE INTO decisions VALUES(?,?,?,?,?,?,?,?,?,?,?)",
            (seed,cycle,decision.action,float(decision.confidence),json.dumps(decision.utilities,sort_keys=True),
             json.dumps(decision.vetoes,sort_keys=True),json.dumps(decision.purpose,sort_keys=True),
             decision.semantic_context,json.dumps(decision.semantic_influence,sort_keys=True),
             decision.dominant_purpose,decision.rationale))


    def log_agency_decision(self,seed,cycle,d):
        self.conn.execute("INSERT OR REPLACE INTO agency_decisions VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (seed,cycle,d.action,json.dumps(list(d.sequence)),json.dumps(list(d.alternative_sequence)),
             float(d.chosen_score),float(d.alternative_score),float(d.preference_gap),float(d.model_confidence),
             json.dumps(d.goal_weights,sort_keys=True),json.dumps(d.goal_contributions,sort_keys=True),
             json.dumps(d.predicted_final_state,sort_keys=True),json.dumps(d.constraints,sort_keys=True),
             d.explanation,int(d.explanation_consistent)))

    def count_agency_decisions(self,seed):
        return self.conn.execute("SELECT COUNT(*) FROM agency_decisions WHERE seed=?",(seed,)).fetchone()[0]

    def save_checkpoint(self,seed,cycle,state_blob,provenance_blob):
        self.conn.execute("INSERT OR REPLACE INTO checkpoints VALUES(?,?,?,?)",
                          (seed,cycle,json.dumps(state_blob),json.dumps(provenance_blob)))
        self.conn.commit()

    def checkpoint(self,seed,cycle):
        row=self.conn.execute("SELECT state_blob,provenance_blob FROM checkpoints WHERE seed=? AND cycle=?",(seed,cycle)).fetchone()
        return None if row is None else (json.loads(row[0]),json.loads(row[1]))

    def count_events(self,seed):
        return self.conn.execute("SELECT COUNT(*) FROM events WHERE seed=?",(seed,)).fetchone()[0]

    def count_decisions(self,seed):
        return self.conn.execute("SELECT COUNT(*) FROM decisions WHERE seed=?",(seed,)).fetchone()[0]

    def close(self): self.conn.commit(); self.conn.close()
