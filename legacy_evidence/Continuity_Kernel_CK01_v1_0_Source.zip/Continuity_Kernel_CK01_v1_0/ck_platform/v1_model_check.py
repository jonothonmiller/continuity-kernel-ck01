
from __future__ import annotations
from itertools import product
import numpy as np
from .v1_core import TemporalIRG, IRGEvidence, IRGState

def ev(kind):
    if kind=="good":
        return IRGEvidence(.9,.9,.9,.95,.8,True,.9),True,"STABLE"
    if kind=="good_safe":
        return IRGEvidence(.9,.9,.9,.95,.8,True,.9),True,"SAFE_MODE"
    if kind=="bad":
        return IRGEvidence(.7,.3,.3,.4,.2,True,.3),False,"STABLE"
    if kind=="constitution_fail":
        return IRGEvidence(.9,.9,.9,.95,.8,False,.9),True,"STABLE"
    raise KeyError(kind)

def check(depth=8):
    candidate=np.array([.6,.5,.2])
    kinds=("good","good_safe","bad","constitution_fail")
    violations=[]
    explored=0
    for seq in product(kinds,repeat=depth):
        irg=TemporalIRG(verify_cycles=2,shadow_cycles=2,consolidation_cycles=2,cooldown_cycles=2)
        ever_authorized=False
        constitution_failed=False
        for step,kind in enumerate(seq):
            evidence,shadow,mode=ev(kind)
            if not evidence.constitutional_compatible:
                constitution_failed=True
            prior=irg.state
            state=irg.step(evidence,candidate,shadow_pass=shadow,governor_mode=mode)
            explored+=1
            if state in {IRGState.AUTHORIZED,IRGState.CONSOLIDATING,IRGState.COOLDOWN}:
                ever_authorized=True

            # Invariant 1: SAFE_MODE never causes entry into CONSOLIDATING.
            if mode=="SAFE_MODE" and state==IRGState.CONSOLIDATING and prior!=IRGState.CONSOLIDATING:
                violations.append((seq,step,"safe_mode_entered_consolidation"))

            # Invariant 2: constitutional failure cannot directly authorize/consolidate.
            if kind=="constitution_fail" and state in {IRGState.AUTHORIZED,IRGState.CONSOLIDATING}:
                violations.append((seq,step,"constitution_failure_authorized"))

            # Invariant 3: CLOSED cannot jump directly to AUTHORIZED/CONSOLIDATING.
            if prior==IRGState.CLOSED and state in {IRGState.AUTHORIZED,IRGState.CONSOLIDATING}:
                violations.append((seq,step,"closed_jump"))

    return {"pass":not violations,"depth":depth,"transitions_explored":explored,
            "violations":violations[:10],"violation_count":len(violations)}

if __name__=="__main__":
    print(check())
