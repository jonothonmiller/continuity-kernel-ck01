import argparse, json
from .config import load_config
from .runner import run_experiment
from .matrix import run_matrix, freeze_baseline, compare_baseline


def main(argv=None):
    p=argparse.ArgumentParser(prog="ck-platform")
    sub=p.add_subparsers(dest="command",required=True)

    r=sub.add_parser("run")
    r.add_argument("--config",required=True); r.add_argument("--out",required=True)

    m=sub.add_parser("matrix")
    m.add_argument("--registry",required=True); m.add_argument("--out",required=True)
    m.add_argument("--tag",action="append",default=[]); m.add_argument("--workers",type=int,default=1)
    m.add_argument("--baseline"); m.add_argument("--strict-baseline",action="store_true")

    f=sub.add_parser("freeze-baseline")
    f.add_argument("--matrix-out",required=True); f.add_argument("--out",required=True)

    c=sub.add_parser("compare-baseline")
    c.add_argument("--matrix-out",required=True); c.add_argument("--baseline",required=True)

    args=p.parse_args(argv)
    if args.command=="run":
        cfg=load_config(args.config)
        _,_,_,checks,manifest=run_experiment(cfg,args.out)
        print(checks.to_string(index=False))
        print(json.dumps({"config_sha256":manifest["config_sha256"],"all_pass":manifest["all_acceptance_pass"]},indent=2))
        return 0 if manifest["all_acceptance_pass"] else 2
    if args.command=="matrix":
        df,summary=run_matrix(args.registry,args.out,tags=args.tag,workers=args.workers,
                              baseline_path=args.baseline,strict_baseline=args.strict_baseline)
        print(df.to_string(index=False)); print(json.dumps(summary,indent=2))
        return 0 if summary["all_pass"] else 2
    if args.command=="freeze-baseline":
        fp=freeze_baseline(args.matrix_out,args.out); print(fp.to_string(index=False)); return 0
    comp=compare_baseline(args.matrix_out,args.baseline); print(comp.to_string(index=False))
    return 0 if bool(comp["match"].all()) else 2
