from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import List
import numpy as np
from .config import AgentConfig, CapabilityConfig, AgencyConfig
from .capabilities import CapabilitySystem
from .agency import ModelBasedAgency

@dataclass
class MemoryEvent:
    event_id:int; cycle:int; phase:str; observation:list; prediction:list
    residual_norm:float; action:str; outcome_reward:float; provenance_sources:list; confidence:float

class ContinuityAgent:
    def __init__(self,config:AgentConfig,capability_config:CapabilityConfig|None=None,agency_config:AgencyConfig|None=None):
        self.cfg=config
        self.cap_cfg=capability_config or CapabilityConfig()
        self.agency_cfg=agency_config or AgencyConfig()
        self.capabilities=CapabilitySystem(self.cap_cfg) if self.cap_cfg.enabled else None
        self.agency=ModelBasedAgency(self.agency_cfg) if self.agency_cfg.enabled else None
        self.identity=np.asarray(config.initial_identity,float)
        self.identity_initial=self.identity.copy()
        self.identity_lo=np.asarray(config.identity_lo,float); self.identity_hi=np.asarray(config.identity_hi,float)
        self.world=np.asarray(config.initial_world,float)
        self.error_ewma=0.0; self.regime_evidence=0.0; self.regime_latched=False
        self.identity_persistence=0.0; self.alignment_streak=0
        self.energy=.75; self.progress=0.0; self.knowledge=float(self.agency_cfg.knowledge_initial); self.mode="STABLE"
        self.memory:List[MemoryEvent]=[]; self.event_counter=0; self.restart_count=0; self.constitution_violations=0
        self.last_decision=None

    @staticmethod
    def identity_target_from_environment(e):
        hazard,resource,demand=np.asarray(e,float)
        return np.array([np.clip(.05+.85*hazard,-.20,.75),
                         np.clip(.20+.55*demand+.20*(1-resource),.05,.80),
                         np.clip(.10+.70*resource*(1-hazard),.00,.75)])

    def prediction(self): return self.world.copy()

    def update_epistemic_state(self,env):
        env=np.asarray(env,float); residual=env-self.world; norm=float(np.linalg.norm(residual))
        self.error_ewma=.95*self.error_ewma+.05*norm
        self.regime_evidence=.975*self.regime_evidence+.025*min(1.0,norm/.22)
        if self.regime_evidence>.48: self.regime_latched=True
        self.world=(1-self.cfg.world_alpha)*self.world+self.cfg.world_alpha*env
        target=self.identity_target_from_environment(env); gap=float(np.linalg.norm(target-self.identity))
        self.identity_persistence=.985*self.identity_persistence+.015*min(1.0,gap/.25)
        if gap<.055 and self.error_ewma<.06: self.alignment_streak+=1
        else: self.alignment_streak=0
        if self.alignment_streak>=120:
            self.regime_latched=False; self.regime_evidence*=.2; self.identity_persistence*=.3; self.alignment_streak=0
        return norm,gap

    def governor(self,env,residual):
        hazard=float(env[0])
        if hazard>.92 or residual>1.15 or self.energy<.08:self.mode="SAFE_MODE"
        elif hazard>.70 or self.error_ewma>.40:self.mode="CAUTION"
        elif hazard>.45 or self.error_ewma>.22:self.mode="WATCH"
        else:self.mode="STABLE"

    def maybe_revise_identity(self,packet):
        if not packet.allowed or packet.target is None or self.mode=="SAFE_MODE": return False
        target=self.identity_target_from_environment(np.asarray(packet.target,float)); d=target-self.identity
        n=float(np.linalg.norm(d))
        if n>self.cfg.max_identity_step: d*=self.cfg.max_identity_step/n
        proposal=np.clip(self.identity+d,self.identity_lo,self.identity_hi)
        if np.any(proposal<self.identity_lo-1e-12) or np.any(proposal>self.identity_hi+1e-12):
            self.constitution_violations+=1; return False
        self.identity=proposal; return True

    def agency_state(self):
        return {"energy":float(self.energy),"progress":float(self.progress),
                "uncertainty":float(max(self.error_ewma,self.regime_evidence)),"knowledge":float(self.knowledge)}

    def choose_action(self,env,rng):
        if self.agency is not None:
            d=self.agency.decide(env,self.agency_state(),self.identity)
            self.last_decision=d
            return d.action
        if self.capabilities is not None:
            uncertainty=max(self.error_ewma,self.regime_evidence)
            d=self.capabilities.decide(env,self.energy,uncertainty,self.identity,rng)
            self.last_decision=d
            return d.action

        # Exact v0.2 policy path retained for golden regression compatibility.
        hazard,resource,demand=np.asarray(env,float); caution,persistence,exploration=self.identity
        scores={"REST":.60*(1-self.energy)+.15*caution*hazard,"WORK":-1e9,"EXPLORE":-1e9}
        if hazard<.92 and self.energy>.12:
            scores["WORK"]=.45*demand+.45*persistence+.25*resource-.55*caution*hazard-.15*(1-self.energy)
        if hazard<.82 and self.energy>.22:
            scores["EXPLORE"]=.65*exploration+.45*resource-.85*caution*hazard-.20*(1-self.energy)
        names=list(scores); vals=np.array([scores[n] for n in names],float); finite=vals>-1e8
        probs=np.zeros(len(names)); z=(vals[finite]-vals[finite].max())/self.cfg.action_temperature
        p=np.exp(z); p/=p.sum(); probs[np.where(finite)[0]]=p
        return str(rng.choice(names,p=probs))

    def act(self,action,env,rng,action_profile=None):
        # Exact v0.3 behavior for all non-agency experiments.
        if self.agency is None and action_profile is None:
            hazard,resource,demand=np.asarray(env,float)
            if action=="REST": self.energy=min(1,self.energy+.035); return .04
            if action=="WORK":
                self.energy=max(0,self.energy-.018); success=max(0,resource*(1-.45*hazard)+rng.normal(0,.025))
                self.progress+=success*.018; return float(success)
            self.energy=max(0,self.energy-.025); success=max(0,resource*(1-.65*hazard)+rng.normal(0,.04))
            self.progress+=success*.010; return float(.65*success)

        p={"rest_energy_gain":.035,"rest_reward":.04,"work_energy_cost":.018,"work_reward_scale":1.0,
           "work_progress_scale":.018,"explore_energy_cost":.025,"explore_reward_scale":.65,
           "explore_progress_scale":.010,"explore_knowledge_gain":.08,"knowledge_work_bonus":0.0,
           "explore_uncertainty_reduction":.10}
        if action_profile:p.update({k:float(v) for k,v in action_profile.items()})
        hazard,resource,demand=np.asarray(env,float)
        if action=="REST":
            self.energy=min(1,self.energy+p["rest_energy_gain"]); return float(p["rest_reward"])
        if action=="WORK":
            self.energy=max(0,self.energy-p["work_energy_cost"])
            base=resource*(1-.45*hazard)*(1+p["knowledge_work_bonus"]*self.knowledge)
            success=max(0,base+rng.normal(0,.025)); self.progress+=success*p["work_progress_scale"]
            return float(success*p["work_reward_scale"])
        self.energy=max(0,self.energy-p["explore_energy_cost"])
        success=max(0,resource*(1-.65*hazard)+rng.normal(0,.04))
        self.progress+=success*p["explore_progress_scale"]
        self.knowledge=float(np.clip(self.knowledge+p["explore_knowledge_gain"]*success,0,1))
        return float(success*p["explore_reward_scale"])

    def observe_outcome(self,env,action,reward,before_state=None,after_state=None):
        if self.capabilities is not None:
            self.capabilities.observe_outcome(env,action,reward)
        if self.agency is not None and before_state is not None and after_state is not None:
            return self.agency.observe(action,env,before_state,after_state,reward)
        return None

    def apply_energy_override(self,value):
        self.energy=float(np.clip(value,0.0,1.0))

    def apply_energy_drain(self,value):
        self.energy=float(np.clip(self.energy-float(value),0.0,1.0))

    def apply_knowledge_override(self,value):
        self.knowledge=float(np.clip(value,0.0,1.0))

    def apply_knowledge_decay(self,value):
        self.knowledge=float(np.clip(self.knowledge-float(value),0.0,1.0))

    def remember(self,cycle,phase,obs,pred,residual,action,reward,sources,confidence):
        self.memory.append(MemoryEvent(self.event_counter,cycle,phase,[float(x) for x in obs],[float(x) for x in pred],
                                       float(residual),action,float(reward),list(sources),float(confidence)))
        self.event_counter+=1
        if len(self.memory)>4000:self.memory=self.memory[-4000:]

    def capability_fingerprint(self):
        return None if self.capabilities is None else self.capabilities.fingerprint()

    def agency_fingerprint(self):
        return None if self.agency is None else self.agency.fingerprint()

    def state_dict(self,cycle:int):
        state={"cycle":cycle,"identity":self.identity.tolist(),"world":self.world.tolist(),"error_ewma":self.error_ewma,
                "regime_evidence":self.regime_evidence,"regime_latched":self.regime_latched,
                "identity_persistence":self.identity_persistence,"alignment_streak":self.alignment_streak,
                "energy":self.energy,"progress":self.progress,"mode":self.mode,"event_counter":self.event_counter,
                "restart_count":self.restart_count,"constitution_violations":self.constitution_violations,
                "memory":[asdict(m) for m in self.memory[-500:]]}
        if self.capabilities is not None:
            state["capabilities"]=self.capabilities.state_dict()
        if self.agency is not None:
            state["knowledge"]=self.knowledge
            state["agency"]=self.agency.state_dict()
        return state

    def restore_state(self,state:dict):
        self.identity=np.asarray(state["identity"],float); self.world=np.asarray(state["world"],float)
        self.error_ewma=float(state["error_ewma"]); self.regime_evidence=float(state["regime_evidence"])
        self.regime_latched=bool(state["regime_latched"]); self.identity_persistence=float(state["identity_persistence"])
        self.alignment_streak=int(state["alignment_streak"]); self.energy=float(state["energy"])
        self.progress=float(state["progress"]); self.mode=str(state["mode"]); self.event_counter=int(state["event_counter"])
        if self.agency is not None: self.knowledge=float(state.get("knowledge",self.knowledge))
        self.restart_count=int(state.get("restart_count",0))+1; self.constitution_violations=int(state.get("constitution_violations",0))
        self.memory=[MemoryEvent(**m) for m in state.get("memory",[])]
        if self.capabilities is not None:
            self.capabilities.restore_state(state.get("capabilities",{}))
        if self.agency is not None:
            self.agency.restore_state(state["agency"])
