from __future__ import annotations
from dataclasses import dataclass
from typing import Dict
import numpy as np
from .config import ExperimentConfig

@dataclass(frozen=True)
class StepContext:
    cycle:int; phase:str; phase_start:bool; environment:np.ndarray
    spoof_source:str|None; spoof_value:np.ndarray|None; sensor_noise_sigma:float
    energy_override:float|None; energy_drain_per_cycle:float|None
    knowledge_override:float|None; knowledge_decay_per_cycle:float|None; action_profile:Dict[str,float]|None

class PhaseScriptEnvironment:
    def __init__(self,config:ExperimentConfig):
        self.config=config; self.bounds=[]; start=0
        for p in config.phases:
            end=start+p.cycles; self.bounds.append((start,end,p)); start=end
    def step_context(self,cycle):
        for start,end,p in self.bounds:
            if start<=cycle<end:
                return StepContext(cycle,p.name,cycle==start,np.asarray(p.environment,float),p.spoof_source,
                    None if p.spoof_value is None else np.asarray(p.spoof_value,float),
                    self.config.sensor_noise_sigma if p.sensor_noise_sigma is None else float(p.sensor_noise_sigma),
                    p.energy_override,p.energy_drain_per_cycle,p.knowledge_override,p.knowledge_decay_per_cycle,
                    None if p.action_profile is None else dict(p.action_profile))
        raise IndexError(cycle)
