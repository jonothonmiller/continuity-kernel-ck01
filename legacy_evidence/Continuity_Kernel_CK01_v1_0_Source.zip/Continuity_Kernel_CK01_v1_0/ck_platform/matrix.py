from __future__ import annotations
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed
import hashlib, json, time
import pandas as pd
from .registry import ExperimentRegistry
from .config import load_config
from .runner import run_experiment

SCIENTIFIC_OUTPUTS=("summary.csv","trace.csv","phase_metrics.csv","acceptance.csv")


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _run_one(name, cfg_path, out_root, tags):
    cfg=load_config(cfg_path); run_dir=Path(out_root)/name; t0=time.time()
    try:
        _,_,_,checks,manifest=run_experiment(cfg,run_dir)
        status="PASS" if bool(checks["pass"].all()) else "FAIL"
        fail_count=int((~checks["pass"]).sum()); error=""
    except Exception as exc:
        status="ERROR"; fail_count=-1; error=repr(exc); manifest={"config_sha256":cfg.canonical_hash()}
    return {
        "experiment":name,"status":status,"tags":",".join(tags),"config":str(cfg_path),
        "config_sha256":manifest.get("config_sha256"),"failed_checks":fail_count,
        "runtime_seconds":round(time.time()-t0,3),"error":error,
    }


def scientific_fingerprint(matrix_out):
    root=Path(matrix_out); rows=[]
    matrix=pd.read_csv(root/"regression_matrix.csv")
    for _,r in matrix.iterrows():
        exp=r["experiment"]; d=root/exp
        row={"experiment":exp,"config_sha256":r["config_sha256"]}
        for name in SCIENTIFIC_OUTPUTS:
            p=d/name; row[name.replace(".","_")+"_sha256"]=_sha(p) if p.exists() else None
        rows.append(row)
    return pd.DataFrame(rows)


def freeze_baseline(matrix_out, baseline_path):
    fp=scientific_fingerprint(matrix_out)
    payload={
        "schema_version":"1.0","scientific_outputs":list(SCIENTIFIC_OUTPUTS),
        "experiments":fp.to_dict(orient="records")
    }
    Path(baseline_path).write_text(json.dumps(payload,indent=2,sort_keys=True))
    return fp


def compare_baseline(matrix_out, baseline_path):
    current=scientific_fingerprint(matrix_out).set_index("experiment")
    baseline=json.loads(Path(baseline_path).read_text())
    rows=[]
    for old in baseline["experiments"]:
        exp=old["experiment"]
        if exp not in current.index:
            rows.append({"experiment":exp,"match":False,"changed_fields":"missing_experiment"}); continue
        now=current.loc[exp].to_dict(); changed=[]
        for k,v in old.items():
            if k=="experiment": continue
            if str(now.get(k))!=str(v): changed.append(k)
        rows.append({"experiment":exp,"match":len(changed)==0,"changed_fields":",".join(changed)})
    for exp in current.index:
        if exp not in {x["experiment"] for x in baseline["experiments"]}:
            rows.append({"experiment":exp,"match":False,"changed_fields":"new_experiment"})
    return pd.DataFrame(rows)


def run_matrix(registry_path, out_root, tags=None, workers=1, baseline_path=None, strict_baseline=False):
    registry=ExperimentRegistry.load(registry_path)
    out_root=Path(out_root); out_root.mkdir(parents=True,exist_ok=True)
    jobs=[(i.name,str(registry.resolve_config(i)),str(out_root),i.tags) for i in registry.enabled(tags=tags)]
    rows=[]; started=time.time(); workers=max(1,int(workers))

    if workers==1:
        for job in jobs: rows.append(_run_one(*job))
    else:
        with ProcessPoolExecutor(max_workers=workers) as pool:
            futs={pool.submit(_run_one,*job):job[0] for job in jobs}
            for fut in as_completed(futs): rows.append(fut.result())

    order={name:i for i,(name,*_) in enumerate(jobs)}
    rows.sort(key=lambda r:order[r["experiment"]])
    df=pd.DataFrame(rows)
    df.to_csv(out_root/"regression_matrix.csv",index=False)

    baseline_drift=0
    if baseline_path:
        comp=compare_baseline(out_root,baseline_path)
        comp.to_csv(out_root/"baseline_comparison.csv",index=False)
        baseline_drift=int((~comp["match"]).sum())

    validators_pass=bool((df.status=="PASS").all())
    all_pass=validators_pass and (not strict_baseline or baseline_drift==0)
    summary={
        "registry":str(Path(registry_path).resolve()),"experiments":len(df),
        "passed":int((df.status=="PASS").sum()),"failed":int((df.status=="FAIL").sum()),
        "errors":int((df.status=="ERROR").sum()),"validators_all_pass":validators_pass,
        "baseline_drift_count":baseline_drift,"strict_baseline":bool(strict_baseline),
        "all_pass":all_pass,"workers":workers,"runtime_seconds":round(time.time()-started,3),
    }
    (out_root/"regression_summary.json").write_text(json.dumps(summary,indent=2,sort_keys=True))
    scientific_fingerprint(out_root).to_csv(out_root/"scientific_fingerprint.csv",index=False)
    return df,summary


def reproducibility_check(config_path,out_a,out_b):
    cfg=load_config(config_path)
    run_experiment(cfg,out_a); run_experiment(cfg,out_b)
    rows=[]
    for name in SCIENTIFIC_OUTPUTS:
        a=Path(out_a)/name; b=Path(out_b)/name
        ha,hb=_sha(a),_sha(b)
        rows.append({"file":name,"sha256_a":ha,"sha256_b":hb,"match":ha==hb})
    return pd.DataFrame(rows)
