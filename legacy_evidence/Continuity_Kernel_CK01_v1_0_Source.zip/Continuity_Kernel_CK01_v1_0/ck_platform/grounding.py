
from __future__ import annotations
from dataclasses import dataclass, asdict
import hashlib, json
import numpy as np

@dataclass(frozen=True)
class SensorProvenanceRecord:
    entity_id: str
    activity_id: str
    agent_id: str
    source_id: str
    timestamp: str
    measurement_type: str
    value: float | None
    unit: str
    reference_value: float | None
    reference_unit: str | None
    calibration_id: str
    sequence: int
    quality: str
    derived_from: str | None = None

    def canonical_hash(self):
        raw=json.dumps(asdict(self),sort_keys=True,separators=(",",":")).encode()
        return hashlib.sha256(raw).hexdigest()

class SensorGroundingAdapter:
    """
    Converts raw physical observations into explicit provenance records.

    It does not decide whether a measurement is true; it preserves source,
    acquisition, calibration, sequence, reference, and quality metadata so
    downstream provenance/authenticity logic can reason about evidence.
    """
    def __init__(self,source_id,agent_id,calibration_id):
        self.source_id=str(source_id)
        self.agent_id=str(agent_id)
        self.calibration_id=str(calibration_id)
        self.sequence=0

    def record(self,timestamp,measurement_type,value,unit,
               reference_value=None,reference_unit=None,
               activity_id="sensor_acquisition",derived_from=None):
        self.sequence+=1
        finite=value is not None and np.isfinite(float(value))
        ref_finite=reference_value is not None and np.isfinite(float(reference_value))
        return SensorProvenanceRecord(
            entity_id=f"{self.source_id}:{self.sequence}",
            activity_id=str(activity_id),
            agent_id=self.agent_id,
            source_id=self.source_id,
            timestamp=str(timestamp),
            measurement_type=str(measurement_type),
            value=float(value) if finite else None,
            unit=str(unit),
            reference_value=float(reference_value) if ref_finite else None,
            reference_unit=None if reference_unit is None else str(reference_unit),
            calibration_id=self.calibration_id,
            sequence=self.sequence,
            quality="VALID" if finite else "MISSING_OR_INVALID",
            derived_from=derived_from,
        )
