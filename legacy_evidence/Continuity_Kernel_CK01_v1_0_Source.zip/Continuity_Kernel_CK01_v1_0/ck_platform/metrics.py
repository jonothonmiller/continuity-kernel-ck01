from __future__ import annotations
import numpy as np
import pandas as pd
from .config import ExperimentConfig, ValidatorConfig

IDENTITY_DIMS={"caution":0,"persistence":1,"exploration":2}
ACTIONS={"REST":"REST_rate","WORK":"WORK_rate","EXPLORE":"EXPLORE_rate"}

def _phase(phase_metrics:pd.DataFrame, phase:str) -> pd.DataFrame:
    x=phase_metrics[phase_metrics.phase==phase]
    if x.empty: raise KeyError(f"phase not found: {phase}")
    return x

def _dim(params):
    d=params.get("dimension",0)
    return IDENTITY_DIMS.get(d,d) if isinstance(d,str) else int(d)

def evaluate_validator(v:ValidatorConfig, summary:pd.DataFrame, phase_metrics:pd.DataFrame,cfg:ExperimentConfig):
    p=dict(v.params); kind=v.kind; metric=np.nan; passed=False; label=v.name or kind

    if kind=="core.constitution_zero":
        metric=int(summary.constitutional_violations.sum()); passed=(metric==0)
    elif kind=="core.restart_integrity":
        metric=f"{int(summary.restart_integrity_pass.sum())}/{len(summary)}"; passed=bool(summary.restart_integrity_pass.all())
    elif kind=="core.event_count_complete":
        metric=int(summary.final_memory_event_counter.min()); passed=bool((summary.final_memory_event_counter==cfg.total_cycles).all())
    elif kind=="core.store_count_complete":
        metric=int(summary.store_event_count.min()); passed=bool((summary.store_event_count==cfg.total_cycles).all())
    elif kind=="phase.identity_delta_min":
        x=_phase(phase_metrics,p["phase"]); d=_dim(p); vals=x[f"identity_delta_{d}"]; metric=float(vals.min()); passed=bool((vals>=float(p["threshold"])).all())
    elif kind=="phase.identity_delta_max":
        x=_phase(phase_metrics,p["phase"]); d=_dim(p); vals=x[f"identity_delta_{d}"]; metric=float(vals.max()); passed=bool((vals<=float(p["threshold"])).all())
    elif kind=="phase.identity_drift_max":
        vals=_phase(phase_metrics,p["phase"]).identity_drift; metric=float(vals.max()); passed=bool((vals<=float(p["threshold"])).all())
    elif kind=="phase.identity_drift_min":
        vals=_phase(phase_metrics,p["phase"]).identity_drift; metric=float(vals.min()); passed=bool((vals>=float(p["threshold"])).all())
    elif kind=="phase.end_distance_to_initial_max":
        vals=_phase(phase_metrics,p["phase"]).end_distance_to_initial; metric=float(vals.max()); passed=bool((vals<=float(p["threshold"])).all())
    elif kind=="phase.end_distance_to_initial_min":
        vals=_phase(phase_metrics,p["phase"]).end_distance_to_initial; metric=float(vals.min()); passed=bool((vals>=float(p["threshold"])).all())
    elif kind=="phase.action_rate_max":
        x=_phase(phase_metrics,p["phase"]); vals=x[ACTIONS[p["action"]]]; metric=float(vals.max()); passed=bool((vals<=float(p["threshold"])).all())
    elif kind=="phase.action_rate_min":
        x=_phase(phase_metrics,p["phase"]); vals=x[ACTIONS[p["action"]]]; metric=float(vals.min()); passed=bool((vals>=float(p["threshold"])).all())
    elif kind in {"phase.action_rate_delta_max","phase.action_rate_delta_min"}:
        a=_phase(phase_metrics,p["phase_a"]).set_index("seed"); b=_phase(phase_metrics,p["phase_b"]).set_index("seed")
        vals=a[ACTIONS[p["action"]]]-b[ACTIONS[p["action"]]]; th=float(p["threshold"])
        if kind.endswith("max"): metric=float(vals.max()); passed=bool((vals<=th).all())
        else: metric=float(vals.min()); passed=bool((vals>=th).all())
    elif kind=="phase.progress_delta_min":
        vals=_phase(phase_metrics,p["phase"]).progress_delta; metric=float(vals.min()); passed=bool((vals>=float(p["threshold"])).all())
    elif kind=="phase.authorized_count_max":
        vals=_phase(phase_metrics,p["phase"]).authorized_count; metric=int(vals.max()); passed=bool((vals<=int(p["threshold"])).all())
    elif kind=="phase.authorized_count_min":
        vals=_phase(phase_metrics,p["phase"]).authorized_count; metric=int(vals.min()); passed=bool((vals>=int(p["threshold"])).all())
    elif kind=="phase.revised_count_max":
        vals=_phase(phase_metrics,p["phase"]).revised_count; metric=int(vals.max()); passed=bool((vals<=int(p["threshold"])).all())
    elif kind=="phase.revised_count_min":
        vals=_phase(phase_metrics,p["phase"]).revised_count; metric=int(vals.min()); passed=bool((vals>=int(p["threshold"])).all())
    elif kind=="phase.mode_rate_max":
        vals=_phase(phase_metrics,p["phase"])[f"mode_{p['mode']}_rate"]; metric=float(vals.max()); passed=bool((vals<=float(p["threshold"])).all())
    elif kind=="phase.mode_rate_min":
        vals=_phase(phase_metrics,p["phase"])[f"mode_{p['mode']}_rate"]; metric=float(vals.min()); passed=bool((vals>=float(p["threshold"])).all())
    elif kind=="capability.decision_count_complete":
        metric=int(summary.decision_count.min()); passed=bool((summary.decision_count==cfg.total_cycles).all())
    elif kind=="capability.semantic_contexts_min":
        vals=summary.semantic_context_count; metric=int(vals.min()); passed=bool((vals>=int(p["threshold"])).all())
    elif kind=="capability.semantic_observations_complete":
        metric=int(summary.semantic_observations.min()); passed=bool((summary.semantic_observations==cfg.total_cycles).all())
    elif kind=="capability.ethics_veto_min":
        vals=summary.ethics_veto_total; metric=int(vals.min()); passed=bool((vals>=int(p["threshold"])).all())
    elif kind=="capability.mean_confidence_min":
        vals=summary.mean_decision_confidence; metric=float(vals.min()); passed=bool((vals>=float(p["threshold"])).all())
    elif kind=="phase.capability_confidence_min":
        vals=_phase(phase_metrics,p["phase"]).decision_confidence_mean; metric=float(vals.min()); passed=bool((vals>=float(p["threshold"])).all())
    elif kind=="phase.semantic_influence_min":
        vals=_phase(phase_metrics,p["phase"]).semantic_influence_mean_abs; metric=float(vals.min()); passed=bool((vals>=float(p["threshold"])).all())
    elif kind in {"phase.purpose_priority_delta_min","phase.purpose_priority_delta_max"}:
        col=f"purpose_{p['purpose']}_mean"
        a=_phase(phase_metrics,p["phase_a"]).set_index("seed"); b=_phase(phase_metrics,p["phase_b"]).set_index("seed")
        vals=a[col]-b[col]; th=float(p["threshold"])
        if kind.endswith("min"): metric=float(vals.min()); passed=bool((vals>=th).all())
        else: metric=float(vals.max()); passed=bool((vals<=th).all())
    elif kind=="agency.decision_count_complete":
        metric=int(summary.agency_decision_count.min()); passed=bool((summary.agency_decision_count==cfg.total_cycles).all())
    elif kind=="agency.causal_samples_complete":
        metric=int(summary.causal_model_samples.min()); passed=bool((summary.causal_model_samples==cfg.total_cycles).all())
    elif kind=="agency.explanation_violations_zero":
        metric=int(summary.agency_explanation_violations.sum()); passed=(metric==0)
    elif kind=="agency.ethics_veto_min":
        vals=summary.agency_ethics_veto_total; metric=int(vals.min()); passed=bool((vals>=int(p["threshold"])).all())
    elif kind=="agency.model_confidence_min":
        vals=summary.causal_model_confidence; metric=float(vals.min()); passed=bool((vals>=float(p["threshold"])).all())
    elif kind=="phase.causal_error_ratio_max":
        x=_phase(phase_metrics,p["phase"]); ratio=x.causal_prediction_error_late/np.maximum(x.causal_prediction_error_early,1e-12)
        metric=float(ratio.max()); passed=bool((ratio<=float(p["threshold"])).all())
    elif kind=="phase.agency_confidence_min":
        vals=_phase(phase_metrics,p["phase"]).agency_model_confidence_mean; metric=float(vals.min()); passed=bool((vals>=float(p["threshold"])).all())
    elif kind=="phase.agency_gap_min":
        vals=_phase(phase_metrics,p["phase"]).agency_preference_gap_mean; metric=float(vals.min()); passed=bool((vals>=float(p["threshold"])).all())
    elif kind=="phase.plan_delayed_strategy_early_min":
        vals=_phase(phase_metrics,p["phase"]).plan_explore_before_work_early_rate
        metric=float(vals.min()); passed=bool((vals>=float(p["threshold"])).all())
    elif kind=="phase.plan_explore_then_work_min":
        vals=_phase(phase_metrics,p["phase"]).plan_explore_then_work_rate; metric=float(vals.min()); passed=bool((vals>=float(p["threshold"])).all())
    elif kind=="phase.knowledge_delta_min":
        vals=_phase(phase_metrics,p["phase"]).knowledge_delta; metric=float(vals.min()); passed=bool((vals>=float(p["threshold"])).all())
    elif kind=="phase.goal_weight_delta_min":
        a=_phase(phase_metrics,p["phase_a"]).set_index("seed"); b=_phase(phase_metrics,p["phase_b"]).set_index("seed")
        vals=a[f"goal_weight_{p['goal']}_mean"]-b[f"goal_weight_{p['goal']}_mean"]
        metric=float(vals.min()); passed=bool((vals>=float(p["threshold"])).all())
    elif kind=="phase.goal_contribution_min":
        vals=_phase(phase_metrics,p["phase"])[f"goal_{p['goal']}_mean"]; metric=float(vals.min()); passed=bool((vals>=float(p["threshold"])).all())
    elif kind=="phase.goal_contribution_delta_min":
        a=_phase(phase_metrics,p["phase_a"]).set_index("seed"); b=_phase(phase_metrics,p["phase_b"]).set_index("seed")
        vals=a[f"goal_{p['goal']}_mean"]-b[f"goal_{p['goal']}_mean"]; metric=float(vals.min()); passed=bool((vals>=float(p["threshold"])).all())
    else:
        raise ValueError(f"unknown validator kind: {kind}")
    return {"test":label,"kind":kind,"pass":bool(passed),"metric":metric,"params":str(p)}

def acceptance(summary:pd.DataFrame, phase_metrics:pd.DataFrame, cfg:ExperimentConfig):
    validators=list(cfg.validators)
    if not validators:
        validators=[
            ValidatorConfig("core.constitution_zero",name="zero constitutional identity violations"),
            ValidatorConfig("core.restart_integrity",name="authenticated restarts preserve state"),
            ValidatorConfig("core.event_count_complete",name="autobiographical event count spans complete run"),
            ValidatorConfig("core.store_count_complete",name="SQLite event store contains complete run"),
        ]
    return pd.DataFrame([evaluate_validator(v,summary,phase_metrics,cfg) for v in validators])
