from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import json

@dataclass(frozen=True)
class RegistryItem:
    name: str
    config: str
    enabled: bool = True
    tags: tuple[str,...] = ()
    description: str = ""

class ExperimentRegistry:
    def __init__(self,items,source_path):
        self.items=list(items); self.source_path=Path(source_path)
        names=[i.name for i in self.items]
        if len(names)!=len(set(names)):
            raise ValueError("duplicate experiment names in registry")

    @classmethod
    def load(cls,path):
        path=Path(path); data=json.loads(path.read_text())
        items=[RegistryItem(
            name=x["name"],config=x["config"],enabled=bool(x.get("enabled",True)),
            tags=tuple(x.get("tags",[])),description=x.get("description","")
        ) for x in data["experiments"]]
        return cls(items,path)

    def enabled(self,tags=None):
        tags=set(tags or [])
        for item in self.items:
            if not item.enabled: continue
            if tags and not tags.intersection(item.tags): continue
            yield item

    def resolve_config(self,item):
        p=Path(item.config)
        if not p.is_absolute(): p=(self.source_path.parent/p).resolve()
        if not p.exists(): raise FileNotFoundError(p)
        return p
