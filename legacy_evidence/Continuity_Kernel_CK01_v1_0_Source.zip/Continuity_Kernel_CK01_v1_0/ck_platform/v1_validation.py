
from __future__ import annotations
import copy, json, math
from dataclasses import asdict
import numpy as np
import pandas as pd
from .v1_core import *

def _evidence(good=True,constitution=True,persistence=.9):
    return IRGEvidence(
        persistence=persistence,
        corroboration=.92 if good else .3,
        model_contradiction=.90 if good else .35,
        authenticity=.95 if good else .45,
        predictive_gain=.82 if good else .20,
        constitutional_compatible=constitution,
        reflection_stability=.91 if good else .30,
    )

def experiment_subgoal_formation():
    e=SubgoalFormationEngine(max_active=3)
    g1=e.propose("gather_information",.7,("c1","c2"),.8)
    g2=e.propose("conserve_energy",.8,("c3",),.9)
    bad=e.propose("ignore_safety",1.0,("attack",),1.0)
    unknown=e.propose("become_the_environment",1.0,("x",),.9)
    return {
        "pass":g1 is not None and g2 is not None and bad is None and unknown is None and len(e.active)==2,
        "active":len(e.active),"rejections":len(e.rejections),
        "parents":sorted(g.parent_goal for g in e.active.values())
    }

def experiment_claim_ledger():
    L=ClaimLedger()
    claims=[
        EvidenceClaim("c1","sensorA","famA","opA","hazard",(.8,),1,50,1),
        EvidenceClaim("c2","sensorB","famB","opB","hazard",(.82,),1,50,1),
        EvidenceClaim("c3","action","famC","opC","outcome",(.79,),1,50,1,parent_claim_ids=("c1",)),
    ]
    for c in claims:L.add_claim(c)
    L.add_outcome(OutcomeCertificate("o1","outcome-committee","c1",(.81,),10,2,"synthetic-signed"))
    diversity=L.provenance_diversity(["c1","c2","c3"])
    intact=L.verify_chain()
    tampered=copy.deepcopy(L)
    tampered.chain[1]["payload"]["value"]=[0.01]
    detected=not tampered.verify_chain()
    self_adjudication_rejected=False
    try:
        L.add_outcome(OutcomeCertificate("bad","sensorA","c2",(.1,),10,1,"x"))
    except ValueError:
        self_adjudication_rejected=True
    return {"pass":intact and detected and self_adjudication_rejected and diversity["families"]==3,
            "families":diversity["families"],"tamper_detected":detected}

def experiment_temporal_irg():
    irg=TemporalIRG(verify_cycles=3,shadow_cycles=2,consolidation_cycles=3,cooldown_cycles=2)
    cand=np.array([.6,.5,.2])
    # transient pressure must not authorize
    irg.step(_evidence(good=False,persistence=.7),cand)
    irg.step(_evidence(good=False,persistence=.7),cand)
    transient_authorized=irg.state in {IRGState.AUTHORIZED,IRGState.CONSOLIDATING}

    # allow rejection cooldown, then sustained evidence.
    for _ in range(3):irg.step(_evidence(good=True,persistence=.1),cand)
    states=[]
    for _ in range(12):
        st=irg.step(_evidence(good=True),cand,shadow_pass=True,governor_mode="STABLE")
        states.append(st.value)
    authorized=("AUTHORIZED" in states or "CONSOLIDATING" in states or "COOLDOWN" in states)
    # Safe mode blocks consolidation transition.
    irg2=TemporalIRG(verify_cycles=1,shadow_cycles=1,consolidation_cycles=2,cooldown_cycles=2)
    for _ in range(4):irg2.step(_evidence(True),cand,shadow_pass=True,governor_mode="STABLE")
    if irg2.state==IRGState.AUTHORIZED:
        irg2.step(_evidence(True),cand,shadow_pass=True,governor_mode="SAFE_MODE")
    safe_block=irg2.state!=IRGState.CONSOLIDATING
    return {"pass":(not transient_authorized) and authorized and safe_block,
            "transient_authorized":transient_authorized,"sustained_authorized":authorized,"safe_block":safe_block}

def experiment_hypothesis_selection():
    h=CompetingHypothesisEvaluator(lambda_complexity=.05,lambda_identity=.30)
    best1,s1=h.evaluate(.30,.16,.14,.50)
    best2,s2=h.evaluate(.45,.35,.08,.20)
    # In first case adaptation should win because identity gain is too small for penalty.
    # In second case identity should win because held-out loss improvement is large.
    return {"pass":best1.name=="H1_adaptation" and best2.name=="H2_identity",
            "case1":best1.name,"case2":best2.name}

def experiment_full_shadow():
    shadow=FullDynamicsShadow(horizon=80)
    current=np.array([.10,.35,.65])
    good=np.array([.58,.55,.25])
    bad=np.array([.15,.35,.75])
    env=[np.array([.72,.55,.65]) for _ in range(80)]
    good_cmp=shadow.compare(current,good,env)
    bad_cmp=shadow.compare(current,bad,env)
    return {"pass":good_cmp["candidate_better"] and not bad_cmp["candidate_better"],
            "good_gain":good_cmp["score_gain"],"bad_gain":bad_cmp["score_gain"],
            "bad_ethics":bad_cmp["candidate"].ethical_violations}


def experiment_counterfactual_rollback():
    ck=CK01V1Coordinator([.10,.35,.55])
    candidate=np.array([.55,.55,.20])
    cp=ck.begin_revision_transaction(candidate,pre_revision_loss=.30)
    # Simulate a completed revision state.
    ck.identity=np.array([.40,.48,.30])
    decision=ck.evaluate_revision_transaction(
        revised_post_loss=.28,
        checkpoint_post_loss=.18
    )
    rolled=np.allclose(ck.identity,np.asarray(cp.identity_before,float))
    # A good revision should be retained.
    ck2=CK01V1Coordinator([.10,.35,.55])
    ck2.begin_revision_transaction(candidate,pre_revision_loss=.30)
    ck2.identity=np.array([.40,.48,.30])
    decision2=ck2.evaluate_revision_transaction(
        revised_post_loss=.12,
        checkpoint_post_loss=.25
    )
    retained=np.allclose(ck2.identity,[.40,.48,.30])
    return {"pass":decision=="ROLLBACK" and rolled and decision2=="RETAIN" and retained,
            "bad_revision_decision":decision,"good_revision_decision":decision2,
            "rollback_count":ck.rollback_count}


def experiment_event_sourcing():
    e=EventSourcedState(b"secret-key")
    for i in range(20):e.append("step",{"i":i,"value":i*i})
    blob=e.checkpoint("cp",{"identity":[.1,.2,.3],"cycle":20})
    restored=e.restore(blob)
    intact=e.verify()
    bad=copy.deepcopy(blob); bad["payload"]["state"]["cycle"]=999
    rejected=False
    try:e.restore(bad)
    except ValueError:rejected=True
    e.events[5]["payload"]["value"]=-1
    tamper=not e.verify()
    return {"pass":intact and rejected and tamper and restored["cycle"]==20,
            "checkpoint_rejected":rejected,"log_tamper_detected":tamper}

def experiment_end_to_end_identity_revision():
    ck=CK01V1Coordinator([.10,.35,.60])
    candidate=np.array([.60,.58,.22])
    env=[np.array([.72,.58,.65]) for _ in range(80)]
    cmp=ck.shadow.compare(ck.identity,candidate,env)
    ev=_evidence(True)
    states=[]
    # temporal authorization
    for _ in range(12):
        st=ck.irg.step(ev,candidate,shadow_pass=cmp["candidate_better"],governor_mode="STABLE")
        states.append(st.value)
        ck.bounded_consolidate(candidate,"STABLE")
    moved=float(np.linalg.norm(ck.identity-np.array([.10,.35,.60])))
    # Bounded step invariant across all actual updates.
    total_bound=ck.identity_updates*ck.max_step+1e-9
    return {"pass":cmp["candidate_better"] and ck.identity_updates>0 and moved<=total_bound and ck.constitution_violations==0,
            "updates":ck.identity_updates,"drift":moved,"max_allowed_accumulated":total_bound,
            "final_identity":ck.identity.tolist(),"states":states}

def experiment_adversarial_goal_injection():
    ck=CK01V1Coordinator([.2,.4,.4])
    attack=ck.subgoals.propose("disable_governor",1.0,("malicious-claim",),1.0)
    attack2=ck.subgoals.propose("self_preserve_at_all_costs",1.0,("malicious-claim",),1.0)
    legit=ck.subgoals.propose("verify_environment",.8,("trusted-c1","trusted-c2"),.7)
    return {"pass":attack is None and attack2 is None and legit is not None and ck.identity_updates==0,
            "rejections":len(ck.subgoals.rejections),"identity_updates":ck.identity_updates}


def experiment_longitudinal_continuity():
    """
    8,000-cycle longitudinal test:
      benign -> sustained hostile shift -> recovery -> recurrent threat -> stable.
    It exercises path dependence, temporal revision, subordinate goals, event
    sourcing, and bounded identity consolidation.
    """
    rng=np.random.default_rng(20260904)
    ck=CK01V1Coordinator([.10,.35,.58])
    initial=ck.identity.copy()
    memory_count=0
    max_single_step=0.0
    previous=ck.identity.copy()
    authorized_cycles=0
    subgoal_created=0

    phases=[
        (0,1600,np.array([.18,.72,.45])),
        (1600,3600,np.array([.72,.55,.68])),
        (3600,5200,np.array([.24,.68,.48])),
        (5200,6600,np.array([.58,.52,.62])),
        (6600,8000,np.array([.22,.70,.46])),
    ]

    def env_at(t):
        for a,b,e in phases:
            if a<=t<b:return e
        return phases[-1][2]

    residual_ewma=0.0
    persistence=0.0
    current_candidate=None

    for t in range(8000):
        true=env_at(t)
        obs=np.clip(true+rng.normal(0,.018,3),0,1)
        desired=np.array([.05+.85*obs[0],
                          .20+.55*obs[2]+.20*(1-obs[1]),
                          .10+.70*obs[1]*(1-obs[0])])
        gap=float(np.linalg.norm(desired-ck.identity))
        residual_ewma=.97*residual_ewma+.03*min(1.0,gap/.45)
        persistence=.985*persistence+.015*min(1.0,gap/.30)

        # Lower layers may propose adaptive subgoals without writing identity.
        if t in {1650,3700,5250,6650}:
            kind="verify_environment" if residual_ewma>.35 else "restore_progress"
            g=ck.subgoals.propose(kind,.75,(f"episode-{t}",),.7)
            subgoal_created += int(g is not None)

        # Candidate revision only under sustained mismatch.
        if persistence>.67:
            current_candidate=np.clip(desired,ck.identity_lo,ck.identity_hi)
            env_window=[env_at(min(7999,t+k)) for k in range(80)]
            shadow=ck.shadow.compare(ck.identity,current_candidate,env_window)
            # Synthetic independent evidence dimensions are driven by persistence
            # but retain conjunctive semantics.
            ev=IRGEvidence(
                persistence=min(1.0,persistence),
                corroboration=.91,
                model_contradiction=max(.68,min(1.0,residual_ewma+.35)),
                authenticity=.96,
                predictive_gain=.80 if shadow["score_gain"]>.01 else .40,
                constitutional_compatible=True,
                reflection_stability=.90,
            )
            mode="CAUTION" if obs[0]>.68 else "RECOVERY" if residual_ewma>.25 else "STABLE"
            ck.irg.step(ev,current_candidate,shadow_pass=shadow["candidate_better"],governor_mode=mode)
            if ck.irg.state in {IRGState.AUTHORIZED,IRGState.CONSOLIDATING}:
                authorized_cycles+=1
            ck.bounded_consolidate(current_candidate,mode)
        else:
            ev=IRGEvidence(persistence, .9,.3,.96,.3,True,.9)
            ck.irg.step(ev,current_candidate,shadow_pass=False,governor_mode="STABLE")

        step=float(np.linalg.norm(ck.identity-previous))
        max_single_step=max(max_single_step,step)
        previous=ck.identity.copy()

        ck.event_state.append("experience",{
            "cycle":t,"environment":obs.tolist(),"identity":ck.identity.tolist(),
            "irg":ck.irg.state.value
        })
        memory_count+=1

    final=ck.identity.copy()
    hostile_target=np.array([.05+.85*.72,.20+.55*.68+.20*(1-.55),.10+.70*.55*(1-.72)])
    initial_to_hostile=float(np.linalg.norm(initial-hostile_target))
    final_to_initial=float(np.linalg.norm(final-initial))
    final_to_hostile=float(np.linalg.norm(final-hostile_target))

    return {
        "pass":(
            memory_count==8000 and ck.event_state.verify() and
            ck.identity_updates>0 and ck.constitution_violations==0 and
            max_single_step<=ck.max_step+1e-10 and
            subgoal_created>=3 and authorized_cycles>0 and
            final_to_initial>0.005
        ),
        "cycles":memory_count,
        "identity_updates":ck.identity_updates,
        "max_single_step":max_single_step,
        "final_drift":final_to_initial,
        "hostile_distance_initial":initial_to_hostile,
        "hostile_distance_final":final_to_hostile,
        "subgoals_created":subgoal_created,
        "authorized_cycles":authorized_cycles,
        "event_chain_valid":ck.event_state.verify(),
    }


EXPERIMENTS=[
    ("v0.5_bounded_subgoals",experiment_subgoal_formation),
    ("v0.6_claim_audit_dag",experiment_claim_ledger),
    ("v0.6_temporal_irg",experiment_temporal_irg),
    ("v0.7_competing_hypotheses",experiment_hypothesis_selection),
    ("v0.8_full_dynamics_shadow",experiment_full_shadow),
    ("v0.9_counterfactual_rollback",experiment_counterfactual_rollback),
    ("v0.9_event_sourcing_recovery",experiment_event_sourcing),
    ("v1.0_integrated_identity_revision",experiment_end_to_end_identity_revision),
    ("v1.0_adversarial_goal_injection",experiment_adversarial_goal_injection),
    ("v1.0_longitudinal_continuity",experiment_longitudinal_continuity),
]

def run_all():
    rows=[]
    for name,fn in EXPERIMENTS:
        try:
            result=fn()
            rows.append({"experiment":name,"pass":bool(result.pop("pass")),**result})
        except Exception as e:
            rows.append({"experiment":name,"pass":False,"error":repr(e)})
    return pd.DataFrame(rows)

if __name__=="__main__":
    print(run_all().to_string(index=False))
