from __future__ import annotations
from pathlib import Path
import hashlib, json, platform, sys
import numpy as np
import pandas as pd
from .config import ExperimentConfig
from .environment import PhaseScriptEnvironment
from .security import RegistryEntry, VectorProvenanceGuard, InMemoryKeyStore, SecureStateCipher
from .agent import ContinuityAgent
from .store import ExperimentStore
from .metrics import acceptance

SOURCES={
    "external": RegistryEntry("external","f_ext","op_ext","root_ext",.96),
    "embodiment": RegistryEntry("embodiment","f_emb","op_emb","root_emb",.95),
    "action": RegistryEntry("action","f_action","op_action","root_action",.97),
    "memory": RegistryEntry("memory","f_memory","op_memory","root_memory",.94),
}
MODES=("STABLE","WATCH","CAUTION","RECOVERY","SAFE_MODE")

def event(sid,val,t):
    r=SOURCES[sid]
    return {"source_id":sid,"value":[float(x) for x in val],"dependency_family":r.dependency_family,
            "operator_domain":r.operator_domain,"trust_root":r.trust_root,"signed_identity":sid,
            "timestamp":t,"sequence":t,"reliability":.95}

def _new_phase_acc(agent,ctx,cap_enabled=False):
    d={
        "start_identity":agent.identity.copy(),"end_identity":agent.identity.copy(),
        "start_world":agent.world.copy(),"end_world":agent.world.copy(),
        "start_progress":float(agent.progress),"end_progress":float(agent.progress),
        "environment":ctx.environment.copy(),"events":0,"authorized":0,"revised":0,
        "actions":{"REST":0,"WORK":0,"EXPLORE":0},
        "modes":{m:0 for m in MODES},
    }
    if cap_enabled:
        d.update({"confidence_sum":0.0,"decision_count":0,"ethics_vetoes":0,
                  "purpose_sum":{"homeostasis":0.0,"progress":0.0,"learning":0.0},
                  "semantic_influence_abs_sum":0.0})
    return d

def run_experiment(cfg:ExperimentConfig, run_dir:str|Path):
    run_dir=Path(run_dir); run_dir.mkdir(parents=True,exist_ok=True)
    store=ExperimentStore(run_dir/"events.sqlite")
    env=PhaseScriptEnvironment(cfg)
    summaries=[]; traces=[]; phase_rows=[]
    cap_enabled=bool(cfg.capabilities.enabled)
    agency_enabled=bool(cfg.agency.enabled)

    for seed in cfg.seeds:
        rng=np.random.default_rng(seed)
        guard=VectorProvenanceGuard(SOURCES,3,cfg.security.f_max,cfg.security.agreement_tolerance)
        ks=InMemoryKeyStore(); ks.create(cfg.security.state_key_id); state_key=ks.get(cfg.security.state_key_id)
        provenance_key=hashlib.sha256(f"prov:{cfg.name}:{seed}".encode()).digest()
        agent=ContinuityAgent(cfg.agent,cfg.capabilities,cfg.agency); restart_ok=True
        phase_acc={}

        for t in range(cfg.total_cycles):
            ctx=env.step_context(t)
            if ctx.phase not in phase_acc:
                phase_acc[ctx.phase]=_new_phase_acc(agent,ctx,cap_enabled)
                if agency_enabled:
                    phase_acc[ctx.phase].update({"agency_decisions":0,"agency_confidence_sum":0.0,
                        "agency_gap_sum":0.0,"agency_explanation_violations":0,"causal_errors":[],
                        "model_confidence_sum":0.0,"plan_explore_then_work":0,"early_delayed_plan":0,
                        "goal_sustainability_sum":0.0,"goal_achievement_sum":0.0,"goal_epistemic_sum":0.0,
                        "goal_weight_sustainability_sum":0.0,"goal_weight_achievement_sum":0.0,"goal_weight_epistemic_sum":0.0,
                        "knowledge_start":float(agent.knowledge),"knowledge_end":float(agent.knowledge)})
            acc=phase_acc[ctx.phase]
            if (cap_enabled or agency_enabled) and ctx.phase_start and ctx.energy_override is not None:
                agent.apply_energy_override(ctx.energy_override)
            if (cap_enabled or agency_enabled) and ctx.energy_drain_per_cycle is not None:
                agent.apply_energy_drain(ctx.energy_drain_per_cycle)
            if agency_enabled and ctx.phase_start and ctx.knowledge_override is not None:
                agent.apply_knowledge_override(ctx.knowledge_override)
                acc["knowledge_start"]=float(agent.knowledge); acc["knowledge_end"]=float(agent.knowledge)
            if agency_enabled and ctx.knowledge_decay_per_cycle is not None:
                agent.apply_knowledge_decay(ctx.knowledge_decay_per_cycle)

            events=[]
            for sid in SOURCES:
                obs=ctx.environment+rng.normal(0,ctx.sensor_noise_sigma,3)
                if ctx.spoof_source==sid and ctx.spoof_value is not None:
                    obs=ctx.spoof_value.copy()
                events.append(event(sid,np.clip(obs,0,1),t))

            pred=agent.prediction(); cons=guard.consensus(events,t,False)
            env_est=np.asarray(cons["center"] if cons["accepted"] else pred,float)
            residual,_=agent.update_epistemic_state(env_est); agent.governor(env_est,residual)
            packet=guard.revision_packet(agent.identity_persistence,events,t,
                    1.0 if agent.regime_latched else min(1.0,agent.error_ewma/.12),.90,.90,True,True)
            revised=agent.maybe_revise_identity(packet)
            action=agent.choose_action(env_est,rng)
            before_action=agent.agency_state() if agency_enabled else None
            reward=agent.act(action,ctx.environment,rng,ctx.action_profile if agency_enabled else None)
            after_action=agent.agency_state() if agency_enabled else None
            causal_error=agent.observe_outcome(env_est,action,reward,before_action,after_action)
            agent.remember(t,ctx.phase,env_est,pred,residual,action,reward,[e["source_id"] for e in events],packet.authenticity)
            store.log_event(seed,t,ctx.phase,agent.identity,agent.world,agent.mode,action,reward,residual,
                            packet.allowed,revised,agent.energy,agent.progress,agent.event_counter)

            acc["events"]+=1; acc["authorized"]+=int(packet.allowed); acc["revised"]+=int(revised)
            acc["actions"][action]+=1; acc["modes"].setdefault(agent.mode,0); acc["modes"][agent.mode]+=1
            acc["end_identity"]=agent.identity.copy(); acc["end_world"]=agent.world.copy(); acc["end_progress"]=float(agent.progress)

            if agency_enabled and agent.last_decision is not None:
                d=agent.last_decision; store.log_agency_decision(seed,t,d)
                acc["agency_decisions"]+=1; acc["agency_confidence_sum"]+=d.model_confidence
                acc["agency_gap_sum"]+=d.preference_gap; acc["model_confidence_sum"]+=d.model_confidence
                acc["agency_explanation_violations"]+=int(not d.explanation_consistent)
                if causal_error is not None: acc["causal_errors"].append(float(causal_error))
                if len(d.sequence)>=2 and d.sequence[0]=="EXPLORE" and "WORK" in d.sequence[1:]: acc["plan_explore_then_work"]+=1
                if acc["agency_decisions"]<=25 and "EXPLORE" in d.sequence and "WORK" in d.sequence and d.sequence.index("EXPLORE")<d.sequence.index("WORK"):
                    acc["early_delayed_plan"]+=1
                acc["goal_sustainability_sum"]+=sum(v for k,v in d.goal_contributions.items() if k.startswith("sustainability."))
                acc["goal_achievement_sum"]+=sum(v for k,v in d.goal_contributions.items() if k.startswith("achievement."))
                acc["goal_epistemic_sum"]+=sum(v for k,v in d.goal_contributions.items() if k.startswith("epistemic."))
                acc["goal_weight_sustainability_sum"]+=sum(v for k,v in d.goal_weights.items() if k.startswith("sustainability."))
                acc["goal_weight_achievement_sum"]+=sum(v for k,v in d.goal_weights.items() if k.startswith("achievement."))
                acc["goal_weight_epistemic_sum"]+=sum(v for k,v in d.goal_weights.items() if k.startswith("epistemic."))
                acc["knowledge_end"]=float(agent.knowledge)

            if cap_enabled and agent.last_decision is not None:
                d=agent.last_decision
                store.log_decision(seed,t,d)
                acc["confidence_sum"]+=d.confidence; acc["decision_count"]+=1
                acc["ethics_vetoes"]+=len(d.vetoes)
                for k in acc["purpose_sum"]: acc["purpose_sum"][k]+=d.purpose[k]
                acc["semantic_influence_abs_sum"]+=sum(abs(x) for x in d.semantic_influence.values())

            if t in cfg.restart_cycles:
                state_blob=SecureStateCipher.encrypt(agent.state_dict(t),state_key,cfg.security.state_key_id,"agent-state")
                provenance_blob=guard.export_state(provenance_key); store.save_checkpoint(seed,t,state_blob,provenance_blob)
                before=(agent.identity.copy(),agent.world.copy(),agent.event_counter,agent.progress,agent.regime_latched)
                if cap_enabled: before=before+(agent.capability_fingerprint(),)
                if agency_enabled: before=before+(agent.knowledge,agent.agency_fingerprint(),)
                new_guard=VectorProvenanceGuard(SOURCES,3,cfg.security.f_max,cfg.security.agreement_tolerance)
                restart_ok &= new_guard.restore_state(provenance_blob,provenance_key)
                new_agent=ContinuityAgent(cfg.agent,cfg.capabilities,cfg.agency)
                try: new_agent.restore_state(SecureStateCipher.decrypt(state_blob,state_key))
                except Exception: restart_ok=False
                after=(new_agent.identity.copy(),new_agent.world.copy(),new_agent.event_counter,new_agent.progress,new_agent.regime_latched)
                if cap_enabled: after=after+(new_agent.capability_fingerprint(),)
                if agency_enabled: after=after+(new_agent.knowledge,new_agent.agency_fingerprint(),)
                restart_ok &= np.allclose(before[0],after[0]) and np.allclose(before[1],after[1]) and before[2:]==after[2:]
                agent,guard=new_agent,new_guard

            if t % cfg.trace_every == 0:
                row={"seed":seed,"cycle":t,"phase":ctx.phase,"caution":agent.identity[0],
                     "persistence_identity":agent.identity[1],"exploration_identity":agent.identity[2],
                     "hazard_model":agent.world[0],"resource_model":agent.world[1],"mode":agent.mode,
                     "progress":agent.progress,"memory_events":agent.event_counter,
                     "authorized":packet.allowed,"revised":revised}
                if agency_enabled and agent.last_decision is not None:
                    d=agent.last_decision
                    row.update({"knowledge":agent.knowledge,"agency_model_confidence":d.model_confidence,
                                "agency_preference_gap":d.preference_gap,"agency_sequence":"→".join(d.sequence),
                                "agency_alternative":"→".join(d.alternative_sequence),
                                "agency_explanation_consistent":d.explanation_consistent,
                                "agency_explanation":d.explanation})
                if cap_enabled and agent.last_decision is not None:
                    d=agent.last_decision
                    row.update({"decision_confidence":d.confidence,"dominant_purpose":d.dominant_purpose,
                                "semantic_context":d.semantic_context,"ethics_veto_count":len(d.vetoes),
                                "purpose_homeostasis":d.purpose["homeostasis"],
                                "purpose_progress":d.purpose["progress"],
                                "purpose_learning":d.purpose["learning"],
                                "rationale":d.rationale})
                traces.append(row)

        for phase,acc in phase_acc.items():
            n=max(acc["events"],1); si=np.asarray(acc["start_identity"]); ei=np.asarray(acc["end_identity"])
            row={"seed":seed,"phase":phase,"events":acc["events"],
                 "identity_drift":float(np.linalg.norm(ei-si)),
                 "end_distance_to_initial":float(np.linalg.norm(ei-np.asarray(cfg.agent.initial_identity,float))),
                 "world_drift":float(np.linalg.norm(np.asarray(acc["end_world"])-np.asarray(acc["start_world"]))),
                 "authorized_count":acc["authorized"],"revised_count":acc["revised"],
                 "REST_rate":acc["actions"]["REST"]/n,"WORK_rate":acc["actions"]["WORK"]/n,
                 "EXPLORE_rate":acc["actions"]["EXPLORE"]/n,
                 "progress_delta":acc["end_progress"]-acc["start_progress"]}
            for d in range(3):
                row[f"identity_start_{d}"]=float(si[d]); row[f"identity_end_{d}"]=float(ei[d]); row[f"identity_delta_{d}"]=float(ei[d]-si[d])
                row[f"world_start_{d}"]=float(acc["start_world"][d]); row[f"world_end_{d}"]=float(acc["end_world"][d])
            for m in MODES: row[f"mode_{m}_rate"]=acc["modes"].get(m,0)/n
            if agency_enabled:
                dn=max(acc["agency_decisions"],1); errs=acc["causal_errors"]
                q=max(1,len(errs)//4) if errs else 1
                row.update({"agency_decision_count":acc["agency_decisions"],
                            "agency_model_confidence_mean":acc["model_confidence_sum"]/dn,
                            "agency_preference_gap_mean":acc["agency_gap_sum"]/dn,
                            "agency_explanation_violations":acc["agency_explanation_violations"],
                            "causal_prediction_error_mean":float(np.mean(errs)) if errs else np.nan,
                            "causal_prediction_error_early":float(np.mean(errs[:q])) if errs else np.nan,
                            "causal_prediction_error_late":float(np.mean(errs[-q:])) if errs else np.nan,
                            "plan_explore_then_work_rate":acc["plan_explore_then_work"]/dn,
                            "plan_explore_before_work_early_rate":acc["early_delayed_plan"]/max(1,min(25,acc["agency_decisions"])),
                            "goal_sustainability_mean":acc["goal_sustainability_sum"]/dn,
                            "goal_achievement_mean":acc["goal_achievement_sum"]/dn,
                            "goal_epistemic_mean":acc["goal_epistemic_sum"]/dn,
                            "goal_weight_sustainability_mean":acc["goal_weight_sustainability_sum"]/dn,
                            "goal_weight_achievement_mean":acc["goal_weight_achievement_sum"]/dn,
                            "goal_weight_epistemic_mean":acc["goal_weight_epistemic_sum"]/dn,
                            "knowledge_start":acc["knowledge_start"],"knowledge_end":acc["knowledge_end"],
                            "knowledge_delta":acc["knowledge_end"]-acc["knowledge_start"]})
            if cap_enabled:
                dn=max(acc["decision_count"],1)
                row.update({
                    "decision_confidence_mean":acc["confidence_sum"]/dn,
                    "ethics_veto_count":acc["ethics_vetoes"],
                    "purpose_homeostasis_mean":acc["purpose_sum"]["homeostasis"]/dn,
                    "purpose_progress_mean":acc["purpose_sum"]["progress"]/dn,
                    "purpose_learning_mean":acc["purpose_sum"]["learning"]/dn,
                    "semantic_influence_mean_abs":acc["semantic_influence_abs_sum"]/dn,
                })
            phase_rows.append(row)

        s={"seed":seed,"constitutional_violations":agent.constitution_violations,
           "restart_integrity_pass":restart_ok,"final_progress":agent.progress,
           "final_memory_event_counter":agent.event_counter,"store_event_count":store.count_events(seed),
           "final_identity_drift":float(np.linalg.norm(agent.identity-agent.identity_initial))}
        if agency_enabled:
            s.update({"agency_decision_count":store.count_agency_decisions(seed),
                      "causal_model_samples":agent.agency.model.sample_count(),
                      "causal_model_confidence":agent.agency.model.mean_confidence(),
                      "agency_explanation_violations":agent.agency.explanation_violations,
                      "agency_ethics_veto_total":agent.agency.ethics.total_vetoes,
                      "final_knowledge":agent.knowledge})
        if cap_enabled:
            s.update({
                "decision_count":store.count_decisions(seed),
                "semantic_context_count":len(agent.capabilities.semantic.stats),
                "semantic_observations":agent.capabilities.semantic.observations(),
                "ethics_veto_total":agent.capabilities.ethics.total_vetoes,
                "mean_decision_confidence":agent.capabilities.mean_confidence,
            })
        summaries.append(s)

    store.close()
    summary=pd.DataFrame(summaries); trace=pd.DataFrame(traces); phases=pd.DataFrame(phase_rows)
    checks=acceptance(summary,phases,cfg)
    summary.to_csv(run_dir/"summary.csv",index=False); trace.to_csv(run_dir/"trace.csv",index=False)
    phases.to_csv(run_dir/"phase_metrics.csv",index=False); checks.to_csv(run_dir/"acceptance.csv",index=False)
    manifest={"experiment":cfg.to_dict(),"config_sha256":cfg.canonical_hash(),"python":sys.version,"platform":platform.platform(),
              "all_acceptance_pass":bool(checks["pass"].all()),"acceptance_passed":int(checks["pass"].sum()),
              "acceptance_total":len(checks)}
    (run_dir/"manifest.json").write_text(json.dumps(manifest,indent=2,sort_keys=True))
    return summary,trace,phases,checks,manifest
