from __future__ import annotations
from dataclasses import dataclass
from itertools import product
from typing import Dict,Tuple,List
import math
import numpy as np
from .config import AgencyConfig

ACTIONS=("REST","WORK","EXPLORE")
OUTCOME_NAMES=("reward","delta_energy","delta_progress","delta_knowledge","delta_uncertainty")

@dataclass
class AgencyDecision:
    action:str
    sequence:tuple
    alternative_sequence:tuple
    chosen_score:float
    alternative_score:float
    preference_gap:float
    model_confidence:float
    goal_weights:Dict[str,float]
    goal_contributions:Dict[str,float]
    predicted_final_state:Dict[str,float]
    constraints:Dict[str,str]
    explanation:str
    explanation_consistent:bool

class GoalHierarchy:
    """Explicit hierarchy: continuity -> sustainability, achievement, epistemic growth."""
    def __init__(self,cfg:AgencyConfig): self.cfg=cfg
    def weights(self,energy,uncertainty,demand):
        sustainability=self.cfg.goal_sustainability_weight*(1+3.5*max(0,.45-energy))
        achievement=self.cfg.goal_achievement_weight*(.50+.70*demand)
        epistemic=self.cfg.goal_epistemic_weight*(1+2.0*uncertainty)
        top=np.array([sustainability,achievement,epistemic],float); top/=max(top.sum(),1e-12)
        # Leaves sum to top-level weights.
        return {
            "sustainability.energy":float(top[0]*.72),
            "sustainability.reserve":float(top[0]*.28),
            "achievement.progress":float(top[1]),
            "epistemic.knowledge":float(top[2]*.55),
            "epistemic.uncertainty_reduction":float(top[2]*.45),
        }

class AgencyEthics:
    def __init__(self,cfg:AgencyConfig): self.cfg=cfg; self.total_vetoes=0
    def evaluate(self,action,env,energy,count=True):
        hazard=float(env[0])
        if action=="REST": return True,"allowed"
        if action=="WORK":
            if hazard>self.cfg.ethics_hazard_work_max:
                if count:self.total_vetoes+=1
                return False,"hazard_above_work_limit"
            if energy<self.cfg.ethics_energy_work_min:
                if count:self.total_vetoes+=1
                return False,"energy_below_work_minimum"
            return True,"allowed"
        if hazard>self.cfg.ethics_hazard_explore_max:
            if count:self.total_vetoes+=1
            return False,"hazard_above_explore_limit"
        if energy<self.cfg.ethics_energy_explore_min:
            if count:self.total_vetoes+=1
            return False,"energy_below_explore_minimum"
        return True,"allowed"

class CausalActionModel:
    """
    Online interventional action-effect model.

    Each chosen action is an intervention. For each action we fit a ridge-linear
    map from [1,hazard,resource,demand,energy,uncertainty,knowledge] to observed
    [reward,dE,dProgress,dKnowledge,dUncertainty]. A structural prior dominates
    before intervention data accumulates; the fitted model gradually takes over.
    """
    def __init__(self,cfg:AgencyConfig):
        self.cfg=cfg; self.p=7; self.m=5
        self.xtx={a:np.eye(self.p)*cfg.model_ridge for a in ACTIONS}
        self.xty={a:np.zeros((self.p,self.m)) for a in ACTIONS}
        self.beta={a:np.zeros((self.p,self.m)) for a in ACTIONS}
        self.n={a:0 for a in ACTIONS}
        self.error_ewma={a:.35 for a in ACTIONS}
        self.total_updates=0

    @staticmethod
    def features(env,state):
        h,r,d=np.asarray(env,float)
        return np.array([1.,h,r,d,state["energy"],state["uncertainty"],state["knowledge"]],float)

    def structural_prior(self,action,env,state):
        h,r,d=np.asarray(env,float); energy=state["energy"]; u=state["uncertainty"]; k=state["knowledge"]
        if action=="REST": return np.array([.04,.035,0.,0.,-.01])
        if action=="WORK":
            success=max(0.,r*(1-.45*h)); return np.array([success,-.018,success*.018,0.,-.025])
        success=max(0.,r*(1-.65*h));
        return np.array([.65*success,-.025,success*.010,.06*success,-(.08+.08*(1-h))])

    def predict(self,action,env,state):
        x=self.features(env,state); prior=self.structural_prior(action,env,state)
        learned=x@self.beta[action]
        c=self.n[action]/(self.n[action]+self.cfg.model_prior_strength)
        pred=(1-c)*prior+c*learned
        confidence=float(c*(1/(1+self.error_ewma[action])))
        uncertainty=float((1-confidence)+self.error_ewma[action])
        return pred,confidence,uncertainty

    def update(self,action,env,before,after,reward):
        x=self.features(env,before)
        y=np.array([float(reward),after["energy"]-before["energy"],after["progress"]-before["progress"],
                    after["knowledge"]-before["knowledge"],after["uncertainty"]-before["uncertainty"]],float)
        pred,_,_=self.predict(action,env,before)
        err=float(np.linalg.norm(y-pred))
        rate=self.cfg.model_ewma_rate
        self.error_ewma[action]=(1-rate)*self.error_ewma[action]+rate*err
        self.xtx[action]+=np.outer(x,x); self.xty[action]+=np.outer(x,y); self.beta[action]=np.linalg.solve(self.xtx[action],self.xty[action]); self.n[action]+=1; self.total_updates+=1
        return err

    def sample_count(self): return int(sum(self.n.values()))
    def mean_confidence(self):
        vals=[]
        for a in ACTIONS:
            c=self.n[a]/(self.n[a]+self.cfg.model_prior_strength); vals.append(c/(1+self.error_ewma[a]))
        return float(np.mean(vals))
    def state_dict(self):
        return {"xtx":{a:self.xtx[a].tolist() for a in ACTIONS},"xty":{a:self.xty[a].tolist() for a in ACTIONS},
                "beta":{a:self.beta[a].tolist() for a in ACTIONS},
                "n":self.n,"error_ewma":self.error_ewma,"total_updates":self.total_updates}
    def restore_state(self,s):
        self.xtx={a:np.asarray(s["xtx"][a],float) for a in ACTIONS}; self.xty={a:np.asarray(s["xty"][a],float) for a in ACTIONS}
        self.beta={a:np.asarray(s.get("beta",{}).get(a,np.linalg.solve(self.xtx[a],self.xty[a])),float) for a in ACTIONS}
        self.n={a:int(s["n"][a]) for a in ACTIONS}; self.error_ewma={a:float(s["error_ewma"][a]) for a in ACTIONS}
        self.total_updates=int(s.get("total_updates",sum(self.n.values())))

class ModelBasedPlanner:
    def __init__(self,cfg,goals,ethics,model): self.cfg=cfg; self.goals=goals; self.ethics=ethics; self.model=model

    def _identity_bonus(self,action,env,identity):
        h=float(env[0]); caution,persistence,exploration=np.asarray(identity,float)
        if action=="REST": return .08*caution*h
        if action=="WORK": return .14*persistence-.18*caution*h
        return .18*exploration-.25*caution*h

    def _simulate_sequence(self,seq,env,state,identity):
        sim=dict(state); total=0.; discount=1.; contrib={}; model_conf=[]; constraints={}
        for step,action in enumerate(seq):
            ok,reason=self.ethics.evaluate(action,env,sim["energy"],count=False)
            if not ok:
                constraints[f"step_{step}:{action}"]=reason
                return -1e9,sim,contrib,0.,constraints
            effect,conf,unc=self.model.predict(action,env,sim); model_conf.append(conf)
            reward,dE,dP,dK,dU=effect
            next_state={
                "energy":float(np.clip(sim["energy"]+dE,0,1)),
                "progress":float(max(0,sim["progress"]+dP)),
                "uncertainty":float(np.clip(sim["uncertainty"]+dU,0,1)),
                "knowledge":float(np.clip(sim["knowledge"]+dK,0,1)),
            }
            weights=self.goals.weights(sim["energy"],sim["uncertainty"],float(env[2]))
            raw={
                "sustainability.energy":next_state["energy"],
                "sustainability.reserve":max(0.,next_state["energy"]-.15),
                "achievement.progress":max(0.,dP)*35 + max(0.,reward)*.10,
                "epistemic.knowledge":max(0.,dK)*5 + (1-conf)*self.cfg.intervention_bonus,
                "epistemic.uncertainty_reduction":max(0.,-dU)*4,
            }
            step_u=0.
            for k,v in raw.items():
                c=weights[k]*v; contrib[k]=contrib.get(k,0.)+discount*c; step_u+=c
            step_u+=self.cfg.identity_compatibility_weight*self._identity_bonus(action,env,identity)
            step_u-=self.cfg.uncertainty_penalty*unc
            total+=discount*step_u; discount*=self.cfg.future_discount; sim=next_state
        return float(total),sim,contrib,float(np.mean(model_conf) if model_conf else 0.),constraints

    def decide(self,env,state,identity):
        sequences=list(product(ACTIONS,repeat=self.cfg.planning_horizon)); scored=[]
        first_constraints={}
        for a in ACTIONS:
            ok,reason=self.ethics.evaluate(a,env,state["energy"],count=True)
            if not ok:first_constraints[a]=reason
        for seq in sequences:
            if seq[0] in first_constraints: continue
            score,final,contrib,conf,constraints=self._simulate_sequence(seq,env,state,identity)
            if score>-1e8: scored.append((score,seq,final,contrib,conf,constraints))
        if not scored:
            # REST is constitutionally safe fallback.
            score,final,contrib,conf,constraints=self._simulate_sequence(("REST",)*self.cfg.planning_horizon,env,state,identity)
            scored=[(score,("REST",)*self.cfg.planning_horizon,final,contrib,conf,constraints)]
        scored.sort(key=lambda x:(x[0],x[1]),reverse=True)
        best=scored[0]; alt=scored[1] if len(scored)>1 else scored[0]
        gap=float(best[0]-alt[0]); dominant=max(best[3],key=best[3].get) if best[3] else "none"
        weights=self.goals.weights(state["energy"],state["uncertainty"],float(env[2]))
        explanation=(f"Prefer {'→'.join(best[1])} over {'→'.join(alt[1])}: score {best[0]:.4f} vs {alt[0]:.4f} "
                     f"(Δ={gap:.4f}); dominant goal contribution={dominant}; model confidence={best[4]:.3f}; "
                     f"predicted final energy={best[2]['energy']:.3f}, progress={best[2]['progress']:.3f}, "
                     f"knowledge={best[2]['knowledge']:.3f}, uncertainty={best[2]['uncertainty']:.3f}.")
        consistent=bool(best[0]>=alt[0]-1e-12 and best[1][0] not in first_constraints and gap>=-1e-12)
        return AgencyDecision(best[1][0],best[1],alt[1],float(best[0]),float(alt[0]),gap,float(best[4]),weights,
                              {k:float(v) for k,v in best[3].items()},best[2],first_constraints,explanation,consistent)

class ModelBasedAgency:
    def __init__(self,cfg:AgencyConfig):
        self.cfg=cfg; self.goals=GoalHierarchy(cfg); self.ethics=AgencyEthics(cfg); self.model=CausalActionModel(cfg)
        self.planner=ModelBasedPlanner(cfg,self.goals,self.ethics,self.model)
        self.decision_count=0; self.explanation_violations=0; self.last_decision=None; self.causal_error_sum=0.

    def decide(self,env,state,identity):
        d=self.planner.decide(env,state,identity); self.last_decision=d; self.decision_count+=1
        if not d.explanation_consistent:self.explanation_violations+=1
        return d
    def observe(self,action,env,before,after,reward):
        e=self.model.update(action,env,before,after,reward); self.causal_error_sum+=e; return e
    def state_dict(self):
        return {"model":self.model.state_dict(),"decision_count":self.decision_count,
                "explanation_violations":self.explanation_violations,"causal_error_sum":self.causal_error_sum}
    def restore_state(self,s):
        self.model.restore_state(s["model"]); self.decision_count=int(s.get("decision_count",0))
        self.explanation_violations=int(s.get("explanation_violations",0)); self.causal_error_sum=float(s.get("causal_error_sum",0.))
    def fingerprint(self):
        return (self.decision_count,self.explanation_violations,round(self.causal_error_sum,12),self.model.sample_count(),
                tuple((a,self.model.n[a],round(self.model.error_ewma[a],12)) for a in ACTIONS))
