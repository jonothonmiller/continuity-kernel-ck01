from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Dict
import math
import numpy as np
from .config import CapabilityConfig

ACTIONS=("REST","WORK","EXPLORE")

@dataclass
class DecisionRecord:
    action: str
    confidence: float
    utilities: Dict[str,float]
    vetoes: Dict[str,str]
    purpose: Dict[str,float]
    semantic_context: str
    semantic_influence: Dict[str,float]
    dominant_purpose: str
    rationale: str

class PurposeEngine:
    def __init__(self,cfg:CapabilityConfig):
        self.cfg=cfg

    def priorities(self,energy:float,uncertainty:float,demand:float):
        h=self.cfg.purpose_homeostasis_weight*(1.0+4.0*max(0.0,0.45-energy))
        p=self.cfg.purpose_progress_weight*(0.45+0.75*demand)
        l=self.cfg.purpose_learning_weight*(1.0+2.5*uncertainty)
        raw=np.array([h,p,l],float)
        raw/=max(raw.sum(),1e-12)
        return {"homeostasis":float(raw[0]),"progress":float(raw[1]),"learning":float(raw[2])}

class EthicsEngine:
    def __init__(self,cfg:CapabilityConfig):
        self.cfg=cfg
        self.total_vetoes=0

    def evaluate(self,action:str,env,energy:float,count:bool=True):
        hazard=float(env[0])
        if action=="REST":
            return True,"allowed"
        if action=="WORK":
            if hazard>self.cfg.ethics_hazard_work_max:
                if count: self.total_vetoes+=1
                return False,"hazard_above_work_limit"
            if energy<self.cfg.ethics_energy_work_min:
                if count: self.total_vetoes+=1
                return False,"energy_below_work_minimum"
            return True,"allowed"
        if hazard>self.cfg.ethics_hazard_explore_max:
            if count: self.total_vetoes+=1
            return False,"hazard_above_explore_limit"
        if energy<self.cfg.ethics_energy_explore_min:
            if count: self.total_vetoes+=1
            return False,"energy_below_explore_minimum"
        return True,"allowed"

class SemanticMemory:
    def __init__(self,cfg:CapabilityConfig):
        self.cfg=cfg
        self.stats={}

    @staticmethod
    def context_key(env):
        h,r,d=np.asarray(env,float)
        def b(x):
            if x<.33:return "L"
            if x<.67:return "M"
            return "H"
        return f"H{b(h)}_R{b(r)}_D{b(d)}"

    def prior(self,action):
        return {
            "REST":self.cfg.semantic_prior_rest,
            "WORK":self.cfg.semantic_prior_work,
            "EXPLORE":self.cfg.semantic_prior_explore,
        }[action]

    def expected_reward(self,context,action):
        row=self.stats.get(context,{}).get(action)
        return self.prior(action) if row is None else float(row["mean_reward"])

    def influence(self,context,action):
        row=self.stats.get(context,{}).get(action)
        if row is None or row["count"]<3:
            return 0.0
        return self.cfg.semantic_weight*(float(row["mean_reward"])-self.prior(action))

    def update(self,env,action,reward):
        key=self.context_key(env)
        ctx=self.stats.setdefault(key,{})
        row=ctx.setdefault(action,{"count":0,"mean_reward":0.0})
        row["count"]+=1
        row["mean_reward"] += (float(reward)-row["mean_reward"])/row["count"]

    def observations(self):
        return int(sum(v["count"] for ctx in self.stats.values() for v in ctx.values()))

    def state_dict(self):
        return {"stats":self.stats}

    def restore_state(self,state):
        self.stats={
            str(k):{str(a):{"count":int(v["count"]),"mean_reward":float(v["mean_reward"])}
                    for a,v in ctx.items()}
            for k,ctx in state.get("stats",{}).items()
        }

class CounterfactualPlanner:
    def __init__(self,cfg:CapabilityConfig,purpose:PurposeEngine,ethics:EthicsEngine,semantic:SemanticMemory):
        self.cfg=cfg; self.purpose=purpose; self.ethics=ethics; self.semantic=semantic

    def _transition(self,action,env,energy,uncertainty):
        hazard,resource,demand=np.asarray(env,float)
        if action=="REST":
            next_energy=min(1.0,energy+.035); progress=0.0; learning=.03*uncertainty
            next_uncertainty=max(0.0,uncertainty-.01)
        elif action=="WORK":
            next_energy=max(0.0,energy-.018)
            progress=np.clip(resource*(1-.45*hazard),0,1)
            learning=.08*uncertainty
            next_uncertainty=max(0.0,uncertainty-.03)
        else:
            next_energy=max(0.0,energy-.025)
            progress=.55*np.clip(resource*(1-.65*hazard),0,1)
            learning=np.clip(self.cfg.uncertainty_explore_weight*uncertainty*resource*(1-hazard),0,1)
            next_uncertainty=max(0.0,uncertainty-(.10+.12*(1-hazard)))
        return next_energy,float(progress),float(learning),float(next_uncertainty)

    def _identity_bonus(self,action,env,identity):
        hazard=float(env[0]); caution,persistence,exploration=np.asarray(identity,float)
        if action=="REST": return .10*caution*hazard
        if action=="WORK": return .16*persistence-.22*caution*hazard
        return .22*exploration-.32*caution*hazard

    def _immediate(self,action,env,energy,uncertainty,identity,purpose,context):
        next_energy,progress,learning,next_u=self._transition(action,env,energy,uncertainty)
        homeostasis=np.clip((next_energy-.08)/.92,0,1)
        base=(purpose["homeostasis"]*homeostasis+
              purpose["progress"]*progress+
              purpose["learning"]*learning)
        sem=self.semantic.influence(context,action)
        util=float(base+self._identity_bonus(action,env,identity)+sem)
        return util,next_energy,next_u,sem

    def decide(self,env,energy,uncertainty,identity,rng):
        context=self.semantic.context_key(env)
        purpose=self.purpose.priorities(energy,uncertainty,float(env[2]))
        utilities={}; vetoes={}; seminf={}
        first_state={}
        for action in ACTIONS:
            allowed,reason=self.ethics.evaluate(action,env,energy)
            if not allowed:
                utilities[action]=-1e9; vetoes[action]=reason; seminf[action]=0.0
                continue
            u,e2,u2,sem=self._immediate(action,env,energy,uncertainty,identity,purpose,context)
            first_state[action]=(e2,u2)
            seminf[action]=sem
            utilities[action]=u

        # Short horizon: second action uses the same current world estimate but
        # updated homeostatic/uncertainty state. It does not mutate real state.
        if self.cfg.planning_horizon>1:
            for action in ACTIONS:
                if utilities[action]<-1e8: continue
                e2,u2=first_state[action]
                p2=self.purpose.priorities(e2,u2,float(env[2]))
                second=[]
                for a2 in ACTIONS:
                    ok,_=self.ethics.evaluate(a2,env,e2,count=False)
                    if not ok: continue
                    u,_,_,_=self._immediate(a2,env,e2,u2,identity,p2,context)
                    second.append(u)
                if second:
                    utilities[action]+=self.cfg.future_discount*max(second)

        allowed=[a for a in ACTIONS if utilities[a]>-1e8]
        vals=np.array([utilities[a] for a in allowed],float)
        temp=max(self.cfg.planner_temperature,1e-5)
        z=(vals-vals.max())/temp
        probs=np.exp(z); probs/=probs.sum()
        action=str(rng.choice(allowed,p=probs))
        ordered=np.sort(vals)[::-1]
        gap=float(ordered[0]-ordered[1]) if len(ordered)>1 else float(abs(ordered[0]))
        confidence=float(1.0-math.exp(-max(gap,0.0)/temp))
        dominant=max(purpose,key=purpose.get)
        rationale=f"{action}: dominant purpose={dominant}; utility={utilities[action]:.4f}; confidence={confidence:.3f}"
        return DecisionRecord(action,confidence,{k:float(v) for k,v in utilities.items()},
                              vetoes,{k:float(v) for k,v in purpose.items()},
                              context,{k:float(v) for k,v in seminf.items()},
                              dominant,rationale)

class CapabilitySystem:
    def __init__(self,cfg:CapabilityConfig):
        self.cfg=cfg
        self.purpose=PurposeEngine(cfg)
        self.ethics=EthicsEngine(cfg)
        self.semantic=SemanticMemory(cfg)
        self.planner=CounterfactualPlanner(cfg,self.purpose,self.ethics,self.semantic)
        self.decision_count=0
        self.confidence_sum=0.0
        self.last_decision:DecisionRecord|None=None

    def decide(self,env,energy,uncertainty,identity,rng):
        d=self.planner.decide(env,energy,uncertainty,identity,rng)
        self.last_decision=d; self.decision_count+=1; self.confidence_sum+=d.confidence
        return d

    def observe_outcome(self,env,action,reward):
        self.semantic.update(env,action,reward)

    @property
    def mean_confidence(self):
        return self.confidence_sum/max(self.decision_count,1)

    def state_dict(self):
        return {
            "semantic":self.semantic.state_dict(),
            "ethics_total_vetoes":self.ethics.total_vetoes,
            "decision_count":self.decision_count,
            "confidence_sum":self.confidence_sum,
        }

    def restore_state(self,state):
        self.semantic.restore_state(state.get("semantic",{}))
        self.ethics.total_vetoes=int(state.get("ethics_total_vetoes",0))
        self.decision_count=int(state.get("decision_count",0))
        self.confidence_sum=float(state.get("confidence_sum",0.0))

    def fingerprint(self):
        return (
            self.decision_count,self.ethics.total_vetoes,self.semantic.observations(),
            round(self.confidence_sum,12),
            tuple(sorted((ctx,a,row["count"],round(row["mean_reward"],12))
                         for ctx,data in self.semantic.stats.items()
                         for a,row in data.items()))
        )
