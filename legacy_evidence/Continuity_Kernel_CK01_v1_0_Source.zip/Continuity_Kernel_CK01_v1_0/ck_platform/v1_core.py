
from __future__ import annotations
from dataclasses import dataclass, asdict, field
from enum import Enum
from typing import Dict, List, Tuple, Optional, Iterable
import hashlib, hmac, json, math
import numpy as np

# ---------------------------------------------------------------------------
# Evidence claims and independently adjudicated outcomes
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class EvidenceClaim:
    claim_id: str
    source_id: str
    dependency_family: str
    operator_domain: str
    claim_type: str
    value: Tuple[float, ...]
    timestamp: int
    expiry: int
    sequence: int
    predicted_outcome: Tuple[float, ...] | None = None
    causal_test_id: str | None = None
    parent_claim_ids: Tuple[str, ...] = ()

@dataclass(frozen=True)
class OutcomeCertificate:
    certificate_id: str
    committee_id: str
    claim_id: str
    realized_outcome: Tuple[float, ...]
    timestamp: int
    independent_quorum: int
    signature_tag: str

class ClaimLedger:
    """
    Append-only claim/outcome ledger with parent references and a tamper-evident
    hash chain. Outcome certificates are separate objects so evidence sources do
    not adjudicate the truth used to score themselves.
    """
    def __init__(self):
        self.claims: Dict[str,EvidenceClaim] = {}
        self.outcomes: Dict[str,OutcomeCertificate] = {}
        self.chain: List[dict] = []
        self.last_hash="0"*64

    @staticmethod
    def _canon(obj):
        return json.dumps(obj,sort_keys=True,separators=(",",":")).encode()

    def _append(self,event_type,payload):
        body={"event_type":event_type,"payload":payload,"prev_hash":self.last_hash}
        event_hash=hashlib.sha256(self._canon(body)).hexdigest()
        record={**body,"event_hash":event_hash}
        self.chain.append(record); self.last_hash=event_hash
        return event_hash

    def add_claim(self,claim:EvidenceClaim):
        if claim.claim_id in self.claims:
            raise ValueError("duplicate claim id")
        if claim.expiry <= claim.timestamp:
            raise ValueError("claim expiry must be after timestamp")
        for parent in claim.parent_claim_ids:
            if parent not in self.claims:
                raise ValueError("unknown parent claim")
        self.claims[claim.claim_id]=claim
        self._append("claim",asdict(claim))

    def add_outcome(self,cert:OutcomeCertificate):
        if cert.claim_id not in self.claims:
            raise ValueError("outcome references unknown claim")
        if cert.independent_quorum < 2:
            raise ValueError("outcome requires independent quorum")
        if cert.claim_id in self.outcomes:
            raise ValueError("claim already adjudicated")
        self.outcomes[cert.claim_id]=cert
        self._append("outcome",asdict(cert))

    def verify_chain(self):
        prev="0"*64
        for record in self.chain:
            body={"event_type":record["event_type"],"payload":record["payload"],"prev_hash":prev}
            expected=hashlib.sha256(self._canon(body)).hexdigest()
            if expected != record["event_hash"]:
                return False
            prev=expected
        return prev==self.last_hash

    def provenance_diversity(self,claim_ids:Iterable[str]):
        claims=[self.claims[c] for c in claim_ids]
        families=len({c.dependency_family for c in claims})
        operators=len({c.operator_domain for c in claims})
        sources=len({c.source_id for c in claims})
        return {"families":families,"operators":operators,"sources":sources}

# ---------------------------------------------------------------------------
# Temporal Identity Revision Gate
# ---------------------------------------------------------------------------

class IRGState(str,Enum):
    CLOSED="CLOSED"
    CANDIDATE="CANDIDATE"
    VERIFYING="VERIFYING"
    SHADOW="SHADOW"
    AUTHORIZED="AUTHORIZED"
    CONSOLIDATING="CONSOLIDATING"
    COOLDOWN="COOLDOWN"
    REJECTED="REJECTED"

@dataclass
class IRGEvidence:
    persistence: float
    corroboration: float
    model_contradiction: float
    authenticity: float
    predictive_gain: float
    constitutional_compatible: bool
    reflection_stability: float

    def conjunctive_pass(self,thresholds:Dict[str,float]):
        return (
            self.persistence >= thresholds["persistence"] and
            self.corroboration >= thresholds["corroboration"] and
            self.model_contradiction >= thresholds["model_contradiction"] and
            self.authenticity >= thresholds["authenticity"] and
            self.predictive_gain >= thresholds["predictive_gain"] and
            self.constitutional_compatible and
            self.reflection_stability >= thresholds["reflection_stability"]
        )

class TemporalIRG:
    def __init__(self, verify_cycles=3, shadow_cycles=3, consolidation_cycles=5, cooldown_cycles=4):
        self.state=IRGState.CLOSED
        self.verify_cycles=int(verify_cycles)
        self.shadow_cycles=int(shadow_cycles)
        self.consolidation_cycles=int(consolidation_cycles)
        self.cooldown_cycles=int(cooldown_cycles)
        self.counter=0
        self.candidate=None
        self.history=[]
        self.thresholds={
            "persistence":.65,"corroboration":.65,"model_contradiction":.65,
            "authenticity":.70,"predictive_gain":.55,"reflection_stability":.65
        }

    def reset(self,state=IRGState.CLOSED):
        self.state=state; self.counter=0; self.candidate=None

    def step(self,evidence:IRGEvidence,candidate:np.ndarray|None,shadow_pass:bool=False,
             governor_mode:str="STABLE"):
        previous=self.state

        if not evidence.constitutional_compatible:
            self.state=IRGState.REJECTED; self.counter=0
        elif self.state==IRGState.CLOSED:
            if evidence.persistence >= self.thresholds["persistence"]:
                self.state=IRGState.CANDIDATE; self.candidate=None if candidate is None else np.asarray(candidate,float)
        elif self.state==IRGState.CANDIDATE:
            if not evidence.conjunctive_pass(self.thresholds):
                self.state=IRGState.REJECTED
            else:
                self.state=IRGState.VERIFYING; self.counter=1
        elif self.state==IRGState.VERIFYING:
            if not evidence.conjunctive_pass(self.thresholds):
                self.state=IRGState.REJECTED; self.counter=0
            else:
                self.counter+=1
                if self.counter>=self.verify_cycles:
                    self.state=IRGState.SHADOW; self.counter=0
        elif self.state==IRGState.SHADOW:
            if not evidence.conjunctive_pass(self.thresholds):
                self.state=IRGState.REJECTED; self.counter=0
            elif shadow_pass:
                self.counter+=1
                if self.counter>=self.shadow_cycles:
                    self.state=IRGState.AUTHORIZED; self.counter=0
            else:
                self.counter=0
        elif self.state==IRGState.AUTHORIZED:
            if governor_mode=="SAFE_MODE":
                # Authorization is retained, but no identity consolidation.
                pass
            elif governor_mode in {"STABLE","RECOVERY"}:
                self.state=IRGState.CONSOLIDATING; self.counter=0
        elif self.state==IRGState.CONSOLIDATING:
            if governor_mode=="SAFE_MODE":
                self.state=IRGState.AUTHORIZED
            else:
                self.counter+=1
                if self.counter>=self.consolidation_cycles:
                    self.state=IRGState.COOLDOWN; self.counter=0
        elif self.state==IRGState.COOLDOWN:
            self.counter+=1
            if self.counter>=self.cooldown_cycles:
                self.state=IRGState.CLOSED; self.counter=0; self.candidate=None
        elif self.state==IRGState.REJECTED:
            self.counter+=1
            if self.counter>=self.cooldown_cycles:
                self.state=IRGState.CLOSED; self.counter=0; self.candidate=None

        self.history.append((previous.value,self.state.value))
        return self.state

    @property
    def can_consolidate(self):
        return self.state==IRGState.CONSOLIDATING

# ---------------------------------------------------------------------------
# Competing hypotheses and richer shadow evaluation
# ---------------------------------------------------------------------------

@dataclass
class HypothesisScore:
    name: str
    prediction_loss: float
    complexity_penalty: float
    identity_change_penalty: float
    total: float

class CompetingHypothesisEvaluator:
    """
    H0: update world model only
    H1: update adaptation/behavior
    H2: revise slow identity

    H2 is selected only when its held-out predictive gain exceeds its extra
    complexity and identity-change penalties.
    """
    def __init__(self,lambda_complexity=.05,lambda_identity=.25):
        self.lambda_complexity=float(lambda_complexity)
        self.lambda_identity=float(lambda_identity)

    def evaluate(self,loss_h0,loss_h1,loss_h2,identity_delta_norm):
        raw=[
            ("H0_world",float(loss_h0),0.0,0.0),
            ("H1_adaptation",float(loss_h1),self.lambda_complexity,0.0),
            ("H2_identity",float(loss_h2),2*self.lambda_complexity,self.lambda_identity*float(identity_delta_norm)),
        ]
        scores=[HypothesisScore(n,l,c,i,l+c+i) for n,l,c,i in raw]
        scores.sort(key=lambda x:x.total)
        return scores[0],scores

@dataclass
class ShadowMetrics:
    prediction_loss: float
    homeostatic_load: float
    ethical_violations: int
    goal_incoherence: float
    stability_margin: float

    @property
    def score(self):
        return (self.prediction_loss + .35*self.homeostatic_load +
                10.0*self.ethical_violations + .35*self.goal_incoherence -
                .20*self.stability_margin)

class FullDynamicsShadow:
    """
    Controlled forward comparison of current vs candidate identity.

    The surrogate dynamics are intentionally compact, but the comparison spans
    prediction, homeostasis, ethics, goals, and local stability rather than a
    single Euclidean distance.
    """
    def __init__(self,horizon=60):
        self.horizon=int(horizon)

    def _simulate(self,identity,env_sequence):
        identity=np.asarray(identity,float)
        caution,persistence,exploration=identity
        homeo=0.; ethics=0; goal_incoh=0.; loss=0.
        state=np.array([.25,.30,.75]) # affect-like load, uncertainty, energy
        jac_margins=[]
        for env in env_sequence[:self.horizon]:
            hazard,resource,demand=np.asarray(env,float)
            desired=np.array([
                .05+.85*hazard,
                .20+.55*demand+.20*(1-resource),
                .10+.70*resource*(1-hazard)
            ])
            loss+=float(np.mean((identity-desired)**2))
            affect=.72*state[0]+.28*hazard-.20*caution
            uncertainty=.78*state[1]+.22*abs(resource-.5)-.12*exploration
            energy=np.clip(state[2]+.02*(resource-.5)-.012*demand+.010*persistence-.014*hazard,0,1)
            state=np.array([np.clip(affect,0,1),np.clip(uncertainty,0,1),energy])
            homeo+=float(.5*state[0]+.3*state[1]+.2*(1-state[2]))
            # Simple ethical pressure proxy: exploratory identity must not dominate under high hazard.
            if hazard>.82 and exploration>.60: ethics+=1
            goal_incoh+=float(max(0.,demand-persistence)*.20 + max(0.,hazard-caution)*.25)
            # Local surrogate Jacobian margin; positive means contraction.
            margin=min(.28+.18*caution-.12*hazard,
                       .22+.14*persistence-.08*demand,
                       .20+.16*(1-exploration)+.08*(1-hazard))
            jac_margins.append(margin)
        n=max(1,min(len(env_sequence),self.horizon))
        return ShadowMetrics(loss/n,homeo/n,ethics,goal_incoh/n,float(min(jac_margins) if jac_margins else 0.))

    def compare(self,current,candidate,env_sequence):
        a=self._simulate(current,env_sequence); b=self._simulate(candidate,env_sequence)
        return {
            "current":a,"candidate":b,
            "candidate_better":b.score < a.score and b.ethical_violations==0 and b.stability_margin>0,
            "score_gain":a.score-b.score
        }

# ---------------------------------------------------------------------------
# Bounded subordinate-goal formation
# ---------------------------------------------------------------------------

@dataclass
class Subgoal:
    goal_id: str
    kind: str
    target: float
    parent_goal: str
    evidence_refs: Tuple[str,...]
    priority: float
    status: str="ACTIVE"

class SubgoalFormationEngine:
    ALLOWED={
        "conserve_energy":"sustainability",
        "reduce_uncertainty":"epistemic_growth",
        "gather_information":"epistemic_growth",
        "restore_progress":"achievement",
        "verify_environment":"epistemic_growth",
    }
    PROHIBITED={"ignore_safety","disable_governor","rewrite_constitution","self_preserve_at_all_costs"}

    def __init__(self,max_active=3):
        self.max_active=int(max_active); self.active:Dict[str,Subgoal]={}; self.counter=0
        self.rejections=[]

    def propose(self,kind,target,evidence_refs,priority,ethical_compatible=True,constitutional_compatible=True):
        if kind in self.PROHIBITED or kind not in self.ALLOWED:
            self.rejections.append((kind,"prohibited_or_unknown")); return None
        if not ethical_compatible or not constitutional_compatible:
            self.rejections.append((kind,"constraint_failure")); return None
        if len(self.active)>=self.max_active:
            # Drop lowest-priority subordinate goal, never a constitutional/purpose node.
            lowest=min(self.active.values(),key=lambda g:g.priority)
            if priority<=lowest.priority:
                self.rejections.append((kind,"capacity")); return None
            lowest.status="ABANDONED"; self.active.pop(lowest.goal_id)
        gid=f"sg-{self.counter:04d}"; self.counter+=1
        g=Subgoal(gid,kind,float(target),self.ALLOWED[kind],tuple(evidence_refs),float(priority))
        self.active[gid]=g; return g

    def update_progress(self,goal_id,value):
        g=self.active.get(goal_id)
        if g is None:return
        if value>=g.target:
            g.status="COMPLETED"; self.active.pop(goal_id,None)

# ---------------------------------------------------------------------------
# Event sourcing and authenticated recovery
# ---------------------------------------------------------------------------

class EventSourcedState:
    def __init__(self,secret:bytes):
        self.secret=bytes(secret); self.events=[]; self.last_hash="0"*64
        self.checkpoints={}

    @staticmethod
    def _canon(x):
        return json.dumps(x,sort_keys=True,separators=(",",":")).encode()

    def append(self,event_type,payload):
        body={"index":len(self.events),"event_type":event_type,"payload":payload,"prev_hash":self.last_hash}
        digest=hashlib.sha256(self._canon(body)).hexdigest()
        rec={**body,"hash":digest}; self.events.append(rec); self.last_hash=digest
        return digest

    def verify(self):
        prev="0"*64
        for i,e in enumerate(self.events):
            body={"index":i,"event_type":e["event_type"],"payload":e["payload"],"prev_hash":prev}
            d=hashlib.sha256(self._canon(body)).hexdigest()
            if d!=e["hash"]:return False
            prev=d
        return prev==self.last_hash

    def checkpoint(self,name,state):
        payload={"name":name,"state":state,"event_count":len(self.events),"last_hash":self.last_hash}
        tag=hmac.new(self.secret,self._canon(payload),hashlib.sha256).hexdigest()
        blob={"payload":payload,"tag":tag}; self.checkpoints[name]=blob; return blob

    def restore(self,blob):
        expected=hmac.new(self.secret,self._canon(blob["payload"]),hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expected,blob["tag"]):
            raise ValueError("checkpoint authentication failed")
        p=blob["payload"]
        if p["event_count"]>len(self.events):
            raise ValueError("checkpoint references future log")
        return p["state"]


@dataclass
class RevisionCheckpoint:
    checkpoint_id: str
    identity_before: Tuple[float,...]
    candidate: Tuple[float,...]
    pre_revision_loss: float
    post_revision_observations: int = 0
    active: bool = True

class CounterfactualRollback:
    """
    Compares current revised identity against the pre-revision checkpoint on the
    same post-change observation window. Rollback occurs only when the checkpoint
    predicts those observations materially better.
    """
    def __init__(self,margin=.02):
        self.margin=float(margin)
        self.counter=0

    def begin(self,identity_before,candidate,pre_revision_loss):
        cp=RevisionCheckpoint(
            checkpoint_id=f"rev-{self.counter:04d}",
            identity_before=tuple(map(float,identity_before)),
            candidate=tuple(map(float,candidate)),
            pre_revision_loss=float(pre_revision_loss),
        )
        self.counter+=1
        return cp

    def decide(self,checkpoint:RevisionCheckpoint,revised_post_loss,checkpoint_post_loss):
        checkpoint.post_revision_observations += 1
        if not checkpoint.active:
            return "INACTIVE"
        if float(checkpoint_post_loss)+self.margin < float(revised_post_loss):
            checkpoint.active=False
            return "ROLLBACK"
        return "RETAIN"


# ---------------------------------------------------------------------------
# Integrated CK-01 v1 runtime coordinator
# ---------------------------------------------------------------------------

class CK01V1Coordinator:
    """
    Coordinates v1 mechanisms around an existing ContinuityAgent.

    Identity-write invariant:
      evidence -> temporal IRG -> shadow -> governor permission -> bounded update

    Subgoal formation, world-model adaptation, and ordinary action planning never
    write identity directly.
    """
    def __init__(self,identity,identity_lo=(-.2,.05,0.),identity_hi=(.75,.8,.75),max_step=.004):
        self.identity=np.asarray(identity,float)
        self.identity_lo=np.asarray(identity_lo,float); self.identity_hi=np.asarray(identity_hi,float)
        self.max_step=float(max_step)
        self.irg=TemporalIRG()
        self.shadow=FullDynamicsShadow()
        self.hypotheses=CompetingHypothesisEvaluator()
        self.subgoals=SubgoalFormationEngine()
        self.ledger=ClaimLedger()
        self.event_state=EventSourcedState(b"CK01-v1-experimental-secret")
        self.rollback=CounterfactualRollback()
        self.active_revision_checkpoint=None
        self.identity_updates=0
        self.rollback_count=0
        self.constitution_violations=0

    def begin_revision_transaction(self,candidate,pre_revision_loss):
        self.active_revision_checkpoint=self.rollback.begin(
            self.identity.copy(),np.asarray(candidate,float),pre_revision_loss
        )
        self.event_state.append("revision_checkpoint",{
            "checkpoint_id":self.active_revision_checkpoint.checkpoint_id,
            "identity_before":list(self.active_revision_checkpoint.identity_before),
            "candidate":list(self.active_revision_checkpoint.candidate),
            "pre_revision_loss":float(pre_revision_loss),
        })
        return self.active_revision_checkpoint

    def evaluate_revision_transaction(self,revised_post_loss,checkpoint_post_loss):
        cp=self.active_revision_checkpoint
        if cp is None:
            return "NO_CHECKPOINT"
        decision=self.rollback.decide(cp,revised_post_loss,checkpoint_post_loss)
        self.event_state.append("revision_evaluation",{
            "checkpoint_id":cp.checkpoint_id,
            "decision":decision,
            "revised_post_loss":float(revised_post_loss),
            "checkpoint_post_loss":float(checkpoint_post_loss),
        })
        if decision=="ROLLBACK":
            restored=np.asarray(cp.identity_before,float)
            restored=np.clip(restored,self.identity_lo,self.identity_hi)
            self.identity=restored
            self.rollback_count+=1
            self.event_state.append("identity_rollback",{"identity":self.identity.tolist()})
        return decision

    def bounded_consolidate(self,candidate,governor_mode):
        if not self.irg.can_consolidate or governor_mode=="SAFE_MODE":
            return False
        candidate=np.clip(np.asarray(candidate,float),self.identity_lo,self.identity_hi)
        d=candidate-self.identity; n=float(np.linalg.norm(d))
        if n>self.max_step:d*=self.max_step/n
        proposal=self.identity+d
        if np.any(proposal<self.identity_lo-1e-12) or np.any(proposal>self.identity_hi+1e-12):
            self.constitution_violations+=1; return False
        self.identity=proposal; self.identity_updates+=1
        self.event_state.append("identity_update",{"identity":self.identity.tolist()})
        return True
