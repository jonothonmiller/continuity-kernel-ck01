# CK-Agent Experimental Platform v0.4 — Regression Report

- **20/20 experiments PASS**
- **6/6 new model-based agency experiments PASS**
- **14/14 v0.3 legacy experiments PASS**
- **0 v0.3 scientific fingerprint drift**
- **15/15 unit, compatibility, smoke, and reproducibility tests PASS**
- **173,570 total agent cycles** in the frozen v0.4 registry
- **29,250 model-based agency cycles**

v0.4 preserves three operating paths: exact v0.2 legacy policy, exact v0.3 capability policy, and opt-in v0.4 model-based agency.

The first fourteen experiments were re-run against the frozen v0.3 SHA-256 scientific baseline and matched exactly. The v0.4 golden baseline now freezes summary, trace, phase metrics, and acceptance outputs for all twenty experiments.

New regression dimensions cover hierarchical goals, causal model adaptation, delayed reward, explanation consistency, model-based operation under provenance attack, and restart persistence of learned causal state.
