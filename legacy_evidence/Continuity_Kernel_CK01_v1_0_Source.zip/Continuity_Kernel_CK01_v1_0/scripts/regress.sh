#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
PYTHONPATH=. python3 -m ck_platform matrix \
  --registry registry/experiments.json \
  --out runs/regression_v0_4 \
  --workers "${CK_WORKERS:-3}" \
  --baseline registry/golden_baseline_v0_4.json \
  --strict-baseline
