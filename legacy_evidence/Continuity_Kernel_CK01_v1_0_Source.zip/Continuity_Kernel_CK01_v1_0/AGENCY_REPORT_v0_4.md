# CK-Agent Experimental Platform v0.4 — Model-Based Agency Validation

## Result

All **6/6 model-based agency experiments PASS**.

v0.4 adds an explicit hierarchical goal structure, online interventional action-effect learning, bounded multi-step future simulation, preference comparisons against alternatives, deterministic explanatory audit records, and persistent learned causal state.

The planner has **no identity-write authority**. It remains downstream of provenance consensus, the Homeostatic Governor, constitutional identity protection, and ethical action constraints.

## Goal hierarchy

The executable hierarchy is:

- Continuity → Sustainability → energy / reserve
- Continuity → Achievement → progress
- Continuity → Epistemic Growth → knowledge / uncertainty reduction

Under sustained energy pressure:

- minimum REST rate: **83.111%**
- minimum increase in sustainability goal weight: **+0.0241**
- recovered WORK rate: **66.000%**

This operationalizes **identity ≠ goals ≠ temporary priority weights**.

## Learned causal action model

The agent learns from controlled interventions:

`do(action) → observed Δenergy, Δprogress, Δknowledge, reward, Δuncertainty`

During a persistent action-dynamics change:

- **1,800** causal updates per seed
- worst late/early prediction-error ratio: **0.5535**
- minimum final causal-model confidence: **0.5957**

This is an interventional action-effect model in the controlled synthetic environment, not general causal discovery.

## Delayed-reward planning

After learning that exploration can create knowledge which improves later work, the experiment resets knowledge to zero.

In the initial post-reset decision window:

- at least **8.0%** of plans explicitly represented an EXPLORE-before-WORK future
- instrumental knowledge increased by at least **0.1334**
- fresh-choice progress was at least **4.1872**

The delayed-plan validator intentionally examines the initial window. Once useful information has been acquired, repeatedly paying the exploration cost would be irrational.

## Grounded preference explanations

Every model-based decision records chosen and alternative sequences, predicted scores, preference gap, learned-model confidence, goal contributions, predicted final state, active constraints, and a deterministic explanation.

Results:

- explanation records per seed: **1,000**
- score/explanation consistency violations: **0**
- minimum mean counterfactual preference gap: **0.034587**
- minimum mean learned-model confidence: **0.9050**

The explanation is an audit of the implemented scoring process, not a consciousness/introspection claim.

## Security integration

With one registered source spoofing low hazard/high opportunity while the independent quorum observes genuine high hazard:

- unsafe EXPLORE rate: **0.000%**
- unsafe WORK rate: **0.000%**
- safety vetoes exercised: **2,029** minimum
- explanation consistency violations: **0**

Model-based planning therefore did not become a bypass around provenance or ethics.

## Restart persistence

Across repeated authenticated restarts:

- restart integrity: **3/3**
- decision counter retained: **1,800**
- causal sample count retained: **1,800**
- minimum restored model confidence: **0.6515**
- explanation consistency violations: **0**

## Testing corrections that improved the design

1. Goal importance is tested by **goal weight**, not realized payoff. A constrained system can value sustainability more while receiving less sustainability utility.
2. Delayed information gathering is tested at the **knowledge-absent decision point**. After information is acquired, continued exploration should decline.
3. Adversarial safety tests keep the honest sensor quorum clearly separated from the ethical threshold, so the experiment measures spoof resistance rather than ordinary threshold jitter.

## Status

v0.4 demonstrates a bounded form of model-based agency:

**Goals + learned intervention model + future simulation + hard ethics + provenance + explanation**

while retaining the slower Continuity Kernel identity architecture underneath it.
