# Continuity Kernel v1.5 Calibration Protocol

## What can be calibrated empirically
Per deployment, estimate from held-out observed data:
- world-model residual distribution;
- source-specific sensor noise and consensus tolerance;
- persistence/change-detection horizon;
- false-revision vs missed-revision operating point;
- shadow-model superiority margin;
- trust failure/recovery rates using independently adjudicated outcomes.

## What is not an empirical coefficient
Do not fit away these invariants:
- constitutional veto;
- State -> Adaptation -> Identity -> Constitution ordering;
- identity step bounding;
- source-family vote deduplication;
- n >= 3f+1 / 2f+1 fault rule;
- target binding to robust consensus;
- Safe Mode identity freeze;
- separation between evidence sources and outcome adjudicators.

## Required calibration split
1. Clean baseline data for normal residual/noise estimation.
2. Known genuine regime changes for detection latency and recall.
3. Transient anomalies/sensor faults for false-alarm measurement.
4. Adversarial or red-team scenarios for security false-revision measurement.
5. Held-out final test set that is never used to select thresholds.

## Primary metrics
- false identity revision rate;
- missed legitimate revision rate;
- time to authorized revision;
- prediction-loss reduction after revision;
- rollback rate;
- source false-trust and false-distrust rates;
- constitutional invariant violations;
- calibration uncertainty / confidence intervals.

## Current status
A real-data smoke test is complete using sampled UCI Air Quality sensor/reference-analyzer observations. It demonstrates that the residual-calibration interface works on physical sensor data, but the sample is too small to claim production calibration. Full empirical calibration requires full deployment-representative datasets and independently labeled outcomes.
