
from __future__ import annotations
import numpy as np

class RobustResidualCalibrator:
    """
    Fits a robust baseline error threshold from empirical out-of-sample residuals.
    Threshold = median(|e|) + k * 1.4826 * MAD(|e|).

    Intended for world-model contradiction calibration, not identity semantics.
    """
    def __init__(self, k: float = 3.0):
        self.k = float(k)
        self.median_ = None
        self.mad_ = None
        self.threshold_ = None

    def fit(self, absolute_residuals):
        r=np.asarray(absolute_residuals,float)
        r=r[np.isfinite(r)]
        if len(r)<8:
            raise ValueError("at least 8 finite out-of-sample residuals required")
        self.median_=float(np.median(r))
        self.mad_=float(np.median(np.abs(r-self.median_)))
        self.threshold_=self.median_ + self.k*1.4826*max(self.mad_,1e-12)
        return self

    def contradiction_score(self, absolute_residual):
        if self.threshold_ is None:
            raise RuntimeError("fit calibrator first")
        x=np.asarray(absolute_residual,float)
        # Smooth score centered on the empirical threshold.
        scale=max(self.mad_*1.4826,1e-9)
        z=(x-self.threshold_)/scale
        return 1/(1+np.exp(-z))
