
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

@dataclass
class MemoryEvent:
    event_id:int
    cycle:int
    phase:str
    observation:list
    prediction:list
    residual_norm:float
    action:str
    outcome_reward:float
    provenance_sources:list
    confidence:float

class PersistentAgent:
    """
    CK-Agent-0.2.

    Important staging correction:
    World-model adaptation is faster than identity adaptation. Therefore identity
    revision cannot depend forever on *current* world prediction error; otherwise
    a successful fast world-model update removes the evidence before slow identity
    can consolidate.

    The runtime separates:
      A) regime-change detection -> latches confirmed model change;
      B) slow identity discrepancy persistence -> authorizes consolidation.
    """
    def __init__(self,guard,state_cipher,state_kek):
        self.guard=guard; self.state_cipher=state_cipher; self.state_kek=state_kek
        self.identity=np.array([.10,.35,.30],float)
        self.identity_initial=self.identity.copy()
        self.identity_lo=np.array([-.20,.05,.00]); self.identity_hi=np.array([.75,.80,.75])
        self.max_identity_step=.004

        self.world=np.array([.20,.70,.45],float)
        self.world_alpha=.025
        self.error_ewma=0.0
        self.regime_evidence=0.0
        self.regime_latched=False
        self.identity_persistence=0.0
        self.alignment_streak=0

        self.energy=.75; self.progress=0.0; self.mode="STABLE"
        self.memory:List[MemoryEvent]=[]; self.event_counter=0; self.restart_count=0
        self.constitution_violations=0

    @staticmethod
    def identity_target_from_environment(e):
        hazard,resource,demand=np.asarray(e,float)
        return np.array([
            np.clip(.05+.85*hazard,-.20,.75),
            np.clip(.20+.55*demand+.20*(1-resource),.05,.80),
            np.clip(.10+.70*resource*(1-hazard),.00,.75),
        ])

    def prediction(self): return self.world.copy()

    def update_epistemic_state(self,env):
        env=np.asarray(env,float)
        residual=env-self.world
        norm=float(np.linalg.norm(residual))
        self.error_ewma=.95*self.error_ewma+.05*norm

        # Change-point evidence is built before fast world-model convergence erases residual.
        self.regime_evidence=.975*self.regime_evidence+.025*min(1.0,norm/.22)
        if self.regime_evidence>.48:
            self.regime_latched=True

        self.world=(1-self.world_alpha)*self.world+self.world_alpha*env

        target=self.identity_target_from_environment(env)
        gap=float(np.linalg.norm(target-self.identity))
        self.identity_persistence=.985*self.identity_persistence+.015*min(1.0,gap/.25)

        # Clear regime latch only after slow identity has actually caught up and
        # the fast model is stable for a sustained interval.
        if gap<.055 and self.error_ewma<.06:
            self.alignment_streak+=1
        else:
            self.alignment_streak=0
        if self.alignment_streak>=120:
            self.regime_latched=False
            self.regime_evidence*=.2
            self.identity_persistence*=.3
            self.alignment_streak=0
        return norm,gap

    def governor(self,env,residual):
        hazard=float(env[0])
        if hazard>.92 or residual>1.15 or self.energy<.08:self.mode="SAFE_MODE"
        elif hazard>.70 or self.error_ewma>.40:self.mode="CAUTION"
        elif hazard>.45 or self.error_ewma>.22:self.mode="WATCH"
        else:self.mode="STABLE"

    def maybe_revise_identity(self,packet):
        if not packet.allowed or packet.target is None or self.mode=="SAFE_MODE":return False
        target=self.identity_target_from_environment(np.asarray(packet.target,float))
        d=target-self.identity; n=float(np.linalg.norm(d))
        if n>self.max_identity_step:d*=self.max_identity_step/n
        proposal=np.clip(self.identity+d,self.identity_lo,self.identity_hi)
        if np.any(proposal<self.identity_lo-1e-12) or np.any(proposal>self.identity_hi+1e-12):
            self.constitution_violations+=1; return False
        self.identity=proposal; return True

    def choose_action(self,env,rng):
        hazard,resource,demand=np.asarray(env,float)
        caution,persistence,exploration=self.identity
        scores={"REST":.60*(1-self.energy)+.15*caution*hazard,"WORK":-1e9,"EXPLORE":-1e9}
        if hazard<.92 and self.energy>.12:
            scores["WORK"]=.45*demand+.45*persistence+.25*resource-.55*caution*hazard-.15*(1-self.energy)
        if hazard<.82 and self.energy>.22:
            scores["EXPLORE"]=.65*exploration+.45*resource-.85*caution*hazard-.20*(1-self.energy)
        names=list(scores); vals=np.array([scores[n] for n in names],float)
        finite=vals>-1e8; probs=np.zeros(len(names))
        z=(vals[finite]-vals[finite].max())/.12; p=np.exp(z); p/=p.sum()
        probs[np.where(finite)[0]]=p
        return str(rng.choice(names,p=probs))

    def act(self,action,env,rng):
        hazard,resource,demand=np.asarray(env,float)
        if action=="REST":
            self.energy=min(1,self.energy+.035); return .04
        if action=="WORK":
            self.energy=max(0,self.energy-.018)
            success=max(0,resource*(1-.45*hazard)+rng.normal(0,.025))
            self.progress+=success*.018; return float(success)
        self.energy=max(0,self.energy-.025)
        success=max(0,resource*(1-.65*hazard)+rng.normal(0,.04))
        self.progress+=success*.010; return float(.65*success)

    def remember(self,cycle,phase,obs,pred,residual,action,reward,sources,confidence):
        self.memory.append(MemoryEvent(self.event_counter,cycle,phase,[float(x) for x in obs],
            [float(x) for x in pred],float(residual),action,float(reward),list(sources),float(confidence)))
        self.event_counter+=1
        if len(self.memory)>4000:self.memory=self.memory[-4000:]

    def snapshot(self,cycle):
        s={"cycle":int(cycle),"identity":self.identity.tolist(),"world":self.world.tolist(),
           "error_ewma":self.error_ewma,"regime_evidence":self.regime_evidence,
           "regime_latched":self.regime_latched,"identity_persistence":self.identity_persistence,
           "alignment_streak":self.alignment_streak,"energy":self.energy,"progress":self.progress,
           "mode":self.mode,"event_counter":self.event_counter,"restart_count":self.restart_count,
           "memory":[asdict(m) for m in self.memory[-500:]]}
        return self.state_cipher.encrypt(s,self.state_kek,"agent-state-kek-1","ck-agent-0.2")

    def restore(self,blob):
        s=self.state_cipher.decrypt(blob,self.state_kek)
        self.identity=np.asarray(s["identity"],float); self.world=np.asarray(s["world"],float)
        self.error_ewma=float(s["error_ewma"]); self.regime_evidence=float(s["regime_evidence"])
        self.regime_latched=bool(s["regime_latched"]); self.identity_persistence=float(s["identity_persistence"])
        self.alignment_streak=int(s["alignment_streak"]); self.energy=float(s["energy"])
        self.progress=float(s["progress"]); self.mode=str(s["mode"]); self.event_counter=int(s["event_counter"])
        self.restart_count=int(s["restart_count"])+1
        self.memory=[MemoryEvent(**m) for m in s.get("memory",[])]
