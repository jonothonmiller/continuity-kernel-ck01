# Continuity Kernel v1.5 — Formal Invariant Strengthening

## Scope
These are architecture-level proofs/lemmas. They strengthen the synthetic testing but do not prove the complete nonlinear agent implementation correct.

### Theorem 1 — Constitutional veto
The Identity Revision Gate uses conjunctive authorization and includes Q_v = 1 as a necessary condition.
Therefore Q_v = 0 implies G_rev = 0 independent of all other evidence scores.

### Theorem 2 — Bounded identity step
Let d = I_candidate - I_t. The update uses
    d' = d * min(1, epsilon_I / ||d||)
when ||d|| > 0.
Then ||d'|| <= epsilon_I by construction.

Machine property test: 100000/100000 passed.

### Theorem 3 — Constitutional-set invariance for convex feasible sets
Let Omega_C be convex, I_t in Omega_C, and P = Pi_OmegaC(I_candidate) in Omega_C.
The capped update is I_(t+1) = (1-alpha) I_t + alpha P with alpha in [0,1].
By convexity, I_(t+1) is in Omega_C.

Machine property test for box-convex Omega_C: 100000/100000 passed.

### Theorem 4 — Byzantine quorum intersection
For n = 3f+1 and q = 2f+1, any two quorums have intersection at least
    2q - n = f + 1 = f+1.
Since at most f domains are Byzantine, the intersection contains at least one honest domain.

### Theorem 5 — Honest membership of a quorum
A q = 2f+1 quorum can contain at most f Byzantine domains, so it contains at least
    q - f = f + 1 = f+1
honest domains.

### Theorem 6 — Reputation cannot create additional votes
The canonical provenance layer aggregates by registered dependency family before consensus.
Therefore changing a source's trust changes its confidence/weight inside its family but not the number of independent family votes.

### Theorem 7 — Revision-target binding
Identity revision uses only the robust provenance-consensus center returned inside the authorized revision packet.
Authorization is therefore not a capability to substitute an arbitrary downstream target.

### Theorem 8 — Replay monotonicity
For each registered source, accepted sequence numbers satisfy seq_t > last_seq.
After authenticated persistence/restoration of last_seq, any replay with seq <= last_seq fails validation.

## Conditional cryptographic claims
Checkpoint/registry integrity based on authenticated cryptography remains conditional on protected key material and the security assumptions of the selected cryptographic implementation. This is not a mathematical proof that keys cannot be stolen.

## Still outside formal proof
- global nonlinear stability of every expanded-system parameterization;
- stochastic reachability under arbitrary noise distributions;
- security when compromised independent trust roots exceed f;
- security if registry governance or key governance is compromised.
