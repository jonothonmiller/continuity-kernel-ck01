# Local Nonlinear Lyapunov Certificate for Canonical A-H-R Dynamics

Reference operating point:
- mu = 0.97 mu_c = 1.313731038448
- equilibrium x* = [-0.6711113818291629, -0.8688459656741202, -0.2746925750339377]
- max Re(lambda(J)) = -0.00366857810411

Because J is Hurwitz, solve

    J^T P + P J = -I.

The computed symmetric P has eigenvalues:
    [0.36089566977019266, 89.19596119141158, 538.0182812174266]

so P is positive definite. Numerical equation residual:
    ||J^T P + P J + I||_2 = 4.101e-14.

For y = x-x*, the cubic nonlinear remainder is exact componentwise:

    R_i(y_i) = -(gamma_i/tau_i) [3 x_i* y_i^2 + y_i^3].

Hence for ||y||_2 <= r,

    ||R(y)||_2 <= C2 ||y||^2 + C3 ||y||^3,

with
    C2 = 0.256880226219
    C3 = 0.124944432093.

For V(y)=y^T P y,

    Vdot <= -||y||^2 + 2 ||P|| ||y|| ||R(y)||

and therefore inside radius r,

    Vdot <= -[1 - 2||P||(C2 r + C3 r^2)] ||y||^2.

The positive critical radius solving

    2||P||(C2 r + C3 r^2) = 1

is
    r_crit = 0.003611437.

Using a 10% safety margin gives the certified local ball

    ||x-x*||_2 <= 0.003250294

with derivative margin

    1 - 2||P||(C2 r + C3 r^2) = 0.100157814 > 0.

Therefore Vdot < 0 for every nonzero state in that ball under the exact
reference cubic A-H-R equations. This is a local nonlinear stability
certificate for the specified parameterization, stronger than eigenvalue-only
local linearization.

It is not a global stability proof and does not apply after crossing the Hopf
boundary or changing the reference coefficients.
