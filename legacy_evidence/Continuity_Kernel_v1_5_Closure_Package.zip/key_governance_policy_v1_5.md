# Continuity Kernel Key Governance v1.5

## Trust boundaries
1. Root/admin private keys SHALL reside outside the application process.
2. Identity-critical registry, signing-key, and revocation changes require dual control (reference profile: 2-of-3 administrators).
3. Runtime signing keys are short-lived and are certified by the admin quorum.
4. Key rotation is monotonic by epoch and linked to the previous key identifier.
5. Revoked, expired, and not-yet-valid signing keys fail closed.
6. Persistent state is encrypted with AES-256-GCM using a KEK supplied by an external protected keystore/HSM boundary.
7. The application SHALL NOT persist raw KEKs, root private keys, or admin private keys.
8. Backup/recovery SHALL preserve key metadata, revocation state, epoch state, and registry fingerprints.
9. Emergency key compromise response SHALL support rapid revocation plus rollback to a known-good signed registry/state checkpoint.
10. Production deployment SHOULD use an appropriate validated cryptographic module where regulatory/security requirements demand it.

## Separation of duties
- Security administrator: key and trust-root policy.
- Operations administrator: runtime/availability authorization.
- Oversight administrator: independent approval/recovery.
No single administrator can unilaterally alter identity-critical trust metadata under the reference 2-of-3 profile.

## Non-claims
This reference Python implementation demonstrates governance logic. It is not itself a FIPS 140-3 validated cryptographic module and does not replace a hardware-backed keystore/HSM in production.
