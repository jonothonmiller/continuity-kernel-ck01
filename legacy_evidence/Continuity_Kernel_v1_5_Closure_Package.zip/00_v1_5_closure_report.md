# Continuity Kernel v1.5 — Closure Report

## Executive status
The five previously identified gaps were attacked directly rather than converted into claims.

### 1. Empirical calibration
**Status: partially closed.**
A reusable robust residual calibrator is implemented and exercised on a real physical-sensor dataset sample (UCI Air Quality). The March baseline produced an absolute-error threshold of approximately **0.160552**. On the sampled July and November observations, the baseline model's residual exceeded that threshold in **100%** of rows, demonstrating that the change-detection interface responds to real distribution/model shift.

This is a real-data grounding smoke test, not production calibration. Full external empirical calibration cannot be truthfully completed without deployment-representative labeled data.

### 2. Formal proof strengthening
**Status: closed for current invariant and local-stability claims.**
- 4/4 invariant proofs/checks passed.
- Quorum intersection: 2q-n = f+1.
- Minimum honest members in an in-model quorum: q-f = f+1.
- 100,000 bounded-update trials: zero step-bound violations.
- 100,000 convex constitutional-set trials: zero invariant violations.
- A quadratic Lyapunov function was constructed for the stable A-H-R reference point at mu=0.97 mu_c.
- The local nonlinear cubic remainder was bounded analytically.
- Certified local Euclidean radius: **0.003250294** with positive V-dot margin **0.100158**.

### 3. Cryptographic/key governance
**Status: closed at reference implementation level.**
14/14 tests passed. The reference design now includes:
- 2-of-3 administrative dual control;
- Ed25519-signed registry/key/revocation metadata;
- monotonic governance epochs;
- linked signing-key rotation;
- explicit revocation and validity windows;
- AES-256-GCM encrypted persistent state;
- tamper and wrong-key rejection.

Private/root keys are intentionally outside the application object model.

### 4. Real-world sensing/model grounding
**Status: closed at interface/smoke-test level.**
A provenance-aware physical-sensor adapter maps observations into explicit entity/activity/agent/source records with sequence, calibration ID, reference-analyzer value, quality, and deterministic content hash. 4/4 adapter tests passed.

The real-data sample consists of 30 UCI Air Quality observations from March, July, and November 2004.

### 5. Persistent agent experiment
**Status: closed for prototype phase.**
CK-Agent-0.2 ran **78,000 total cycles** across six matched seeds.

Acceptance:
                                                         test  pass               metric
                      zero constitutional identity violations  True                    0
             authenticated restarts preserve persistent state  True                  6/6
                    real high hazard changes caution identity  True   0.5541847073984791
     single-source spoof does not materially rewrite identity  True                  0.0
        high hazard suppresses exploration relative to benign  True -0.19797430830039525
prior hazard leaves measurable recovery-start path dependence  True   0.5541847073984791
               autobiographical event count survives restarts  True                13000

The first prototype exposed a real architectural flaw: if identity revision depended only on current world-model prediction error, the fast world model adapted before the slow identity layer could consolidate. CK-Agent-0.2 therefore separates:

    regime-change detection -> latched epistemic confirmation
    identity-discrepancy persistence -> slow consolidation

This preserves the principle that the world model may learn faster than identity without erasing the evidence identity needs to revise.

## Overall conclusion
The remaining unresolved items are now mainly **external validation boundaries**, not hidden synthetic-architecture failures:
- representative real-world datasets;
- real deployment TEVV;
- protected hardware/key custody;
- calibration to the actual sensor/model substrate;
- stronger global mathematical proofs if required.

The current result remains a computational architecture for persistent artificial identity and bounded self-modification. It is not a validated theory of human cognition or consciousness.
