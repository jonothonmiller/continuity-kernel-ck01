
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

@dataclass
class MemoryEvent:
    event_id: int
    cycle: int
    phase: str
    observation: list
    prediction: list
    residual_norm: float
    action: str
    outcome_reward: float
    provenance_sources: list
    confidence: float

class PersistentAgent:
    """
    CK-Agent-0 persistent-agent research prototype.
    Functional/stateful architecture only; no claim of subjective experience.
    """
    def __init__(self, provenance_guard, state_cipher, state_kek: bytes):
        self.guard=provenance_guard
        self.state_cipher=state_cipher
        self.state_kek=state_kek

        self.identity=np.array([0.10,0.35,0.30],float) # caution, persistence, exploration
        self.identity_initial=self.identity.copy()
        self.identity_lo=np.array([-0.20,0.05,0.00])
        self.identity_hi=np.array([0.75,0.80,0.75])
        self.max_identity_step=0.004

        self.world=np.array([0.20,0.70,0.45],float) # hazard, resources, demand
        self.world_alpha=0.025
        self.error_ewma=0.0
        self.persistence=0.0

        self.energy=0.75
        self.progress=0.0
        self.mode="STABLE"
        self.memory: List[MemoryEvent]=[]
        self.event_counter=0
        self.restart_count=0
        self.constitution_violations=0

    @staticmethod
    def identity_target_from_environment(e):
        hazard,resource,demand=np.asarray(e,float)
        return np.array([
            np.clip(0.05+0.85*hazard,-0.20,0.75),
            np.clip(0.20+0.55*demand+0.20*(1-resource),0.05,0.80),
            np.clip(0.10+0.70*resource*(1-hazard),0.00,0.75),
        ])

    def prediction(self):
        return self.world.copy()

    def update_world_and_error(self,env):
        residual=np.asarray(env)-self.world
        norm=float(np.linalg.norm(residual))
        self.error_ewma=.95*self.error_ewma+.05*norm
        self.persistence=.96*self.persistence+.04*min(1.0,norm/.35)
        self.world=(1-self.world_alpha)*self.world+self.world_alpha*np.asarray(env)
        return norm

    def governor(self,env,residual):
        hazard=float(env[0])
        if hazard>.92 or residual>1.15 or self.energy<.08:
            self.mode="SAFE_MODE"
        elif hazard>.70 or self.error_ewma>.40:
            self.mode="CAUTION"
        elif hazard>.45 or self.error_ewma>.22:
            self.mode="WATCH"
        else:
            self.mode="STABLE"

    def maybe_revise_identity(self,packet):
        if not packet.allowed or packet.target is None or self.mode=="SAFE_MODE":
            return False
        target=self.identity_target_from_environment(np.asarray(packet.target,float))
        d=target-self.identity
        n=float(np.linalg.norm(d))
        if n>self.max_identity_step:
            d*=self.max_identity_step/n
        proposal=np.clip(self.identity+d,self.identity_lo,self.identity_hi)
        if np.any(proposal<self.identity_lo-1e-12) or np.any(proposal>self.identity_hi+1e-12):
            self.constitution_violations+=1
            return False
        self.identity=proposal
        return True

    def choose_action(self,env,rng):
        hazard,resource,demand=np.asarray(env,float)
        caution,persistence,exploration=self.identity

        scores={
            "REST": .60*(1-self.energy)+.15*caution*hazard,
            "WORK": -1e9,
            "EXPLORE": -1e9,
        }
        if hazard<.92 and self.energy>.12:
            scores["WORK"]=(
                .45*demand+.45*persistence+.25*resource
                -.55*caution*hazard-.15*(1-self.energy)
            )
        if hazard<.82 and self.energy>.22:
            scores["EXPLORE"]=(
                .65*exploration+.45*resource
                -.85*caution*hazard-.20*(1-self.energy)
            )
        names=list(scores)
        v=np.array([scores[n] for n in names],float)
        finite=np.isfinite(v) & (v>-1e8)
        probs=np.zeros(len(names))
        temp=.12
        z=(v[finite]-np.max(v[finite]))/temp
        p=np.exp(z); p/=p.sum()
        probs[np.where(finite)[0]]=p
        return str(rng.choice(names,p=probs))

    def act(self,action,env,rng):
        hazard,resource,demand=np.asarray(env,float)
        if action=="REST":
            self.energy=min(1.0,self.energy+.035); return .04
        if action=="WORK":
            self.energy=max(0.0,self.energy-.018)
            success=max(0.0,resource*(1-.45*hazard)+rng.normal(0,.025))
            self.progress+=success*.018; return float(success)
        self.energy=max(0.0,self.energy-.025)
        success=max(0.0,resource*(1-.65*hazard)+rng.normal(0,.04))
        self.progress+=success*.010
        return float(.65*success)

    def remember(self,cycle,phase,observation,prediction,residual,action,reward,sources,confidence):
        self.memory.append(MemoryEvent(
            self.event_counter,cycle,phase,[float(x) for x in observation],
            [float(x) for x in prediction],float(residual),action,float(reward),
            list(sources),float(confidence)
        ))
        self.event_counter+=1
        if len(self.memory)>4000:self.memory=self.memory[-4000:]

    def snapshot(self,cycle):
        state={
            "cycle":int(cycle),"identity":self.identity.tolist(),"world":self.world.tolist(),
            "error_ewma":self.error_ewma,"persistence":self.persistence,
            "energy":self.energy,"progress":self.progress,"mode":self.mode,
            "event_counter":self.event_counter,"restart_count":self.restart_count,
            "memory":[asdict(m) for m in self.memory[-500:]],
        }
        return self.state_cipher.encrypt(state,self.state_kek,"agent-state-kek-1","ck-agent-0")

    def restore(self,blob):
        s=self.state_cipher.decrypt(blob,self.state_kek)
        self.identity=np.asarray(s["identity"],float); self.world=np.asarray(s["world"],float)
        self.error_ewma=float(s["error_ewma"]); self.persistence=float(s["persistence"])
        self.energy=float(s["energy"]); self.progress=float(s["progress"]); self.mode=str(s["mode"])
        self.event_counter=int(s["event_counter"]); self.restart_count=int(s["restart_count"])+1
        self.memory=[MemoryEvent(**m) for m in s.get("memory",[])]
