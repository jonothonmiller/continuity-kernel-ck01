
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Dict, Iterable, List, Mapping, Optional, Sequence, Set, Tuple
from types import MappingProxyType
import base64, hashlib, json, os, time

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives import serialization

def canonical_json(obj) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",",":")).encode("utf-8")

def b64e(b: bytes) -> str:
    return base64.b64encode(b).decode("ascii")

def b64d(s: str) -> bytes:
    return base64.b64decode(s.encode("ascii"))

def pub_bytes(pub: Ed25519PublicKey) -> bytes:
    return pub.public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw
    )

@dataclass(frozen=True)
class AdminIdentity:
    admin_id: str
    public_key_b64: str
    role: str

@dataclass(frozen=True)
class SigningKeyCertificate:
    key_id: str
    public_key_b64: str
    epoch: int
    not_before: int
    not_after: int
    previous_key_id: str | None
    purpose: str

@dataclass(frozen=True)
class SignedEnvelope:
    payload: dict
    signatures: dict  # admin_id -> b64 signature

class GovernanceError(Exception):
    pass

class AdminQuorum:
    """
    Threshold administrative governance.

    Default policy: 2-of-3 distinct administrator signatures.
    Signatures authorize metadata; private admin keys are never stored here.
    """
    def __init__(self, admins: Sequence[AdminIdentity], threshold: int = 2):
        admins = list(admins)
        if threshold < 2:
            raise GovernanceError("threshold must require dual control")
        if len(admins) < threshold:
            raise GovernanceError("not enough administrators")
        if len({a.admin_id for a in admins}) != len(admins):
            raise GovernanceError("duplicate admin IDs")
        self.admins = MappingProxyType({a.admin_id:a for a in admins})
        self.threshold = int(threshold)

    def verify_envelope(self, env: SignedEnvelope) -> bool:
        raw = canonical_json(env.payload)
        valid = set()
        for admin_id, sig_b64 in env.signatures.items():
            admin = self.admins.get(admin_id)
            if admin is None:
                continue
            try:
                pub = Ed25519PublicKey.from_public_bytes(b64d(admin.public_key_b64))
                pub.verify(b64d(sig_b64), raw)
                valid.add(admin_id)
            except Exception:
                pass
        return len(valid) >= self.threshold

class KeyGovernance:
    """
    Key metadata governance.

    - registry manifests require admin quorum;
    - signing-key certificates require admin quorum;
    - revocation manifests require admin quorum;
    - key epochs cannot move backward;
    - revoked or expired keys fail verification.
    """
    def __init__(self, admin_quorum: AdminQuorum):
        self.admin_quorum = admin_quorum
        self.current_epoch = -1
        self.registry_hash = None
        self.signing_keys: Dict[str, SigningKeyCertificate] = {}
        self.revoked: Set[str] = set()

    def install_registry_manifest(self, env: SignedEnvelope):
        if not self.admin_quorum.verify_envelope(env):
            raise GovernanceError("registry manifest lacks valid admin quorum")
        p = env.payload
        if p.get("type") != "registry_manifest":
            raise GovernanceError("wrong manifest type")
        epoch = int(p["epoch"])
        if epoch < self.current_epoch:
            raise GovernanceError("registry epoch rollback rejected")
        self.current_epoch = epoch
        self.registry_hash = str(p["registry_hash"])

    def install_signing_key(self, env: SignedEnvelope):
        if not self.admin_quorum.verify_envelope(env):
            raise GovernanceError("signing key certificate lacks valid admin quorum")
        p = env.payload
        if p.get("type") != "signing_key_certificate":
            raise GovernanceError("wrong certificate type")
        cert = SigningKeyCertificate(
            key_id=p["key_id"],
            public_key_b64=p["public_key_b64"],
            epoch=int(p["epoch"]),
            not_before=int(p["not_before"]),
            not_after=int(p["not_after"]),
            previous_key_id=p.get("previous_key_id"),
            purpose=p["purpose"],
        )
        if cert.epoch < self.current_epoch:
            raise GovernanceError("key certificate epoch rollback rejected")
        if cert.not_after <= cert.not_before:
            raise GovernanceError("invalid key lifetime")
        if cert.previous_key_id is not None and cert.previous_key_id not in self.signing_keys:
            raise GovernanceError("rotation predecessor unknown")
        self.signing_keys[cert.key_id] = cert
        self.current_epoch = max(self.current_epoch, cert.epoch)

    def install_revocations(self, env: SignedEnvelope):
        if not self.admin_quorum.verify_envelope(env):
            raise GovernanceError("revocation manifest lacks valid admin quorum")
        p = env.payload
        if p.get("type") != "revocation_manifest":
            raise GovernanceError("wrong revocation type")
        epoch = int(p["epoch"])
        if epoch < self.current_epoch:
            raise GovernanceError("revocation epoch rollback rejected")
        for key_id in p.get("revoked_key_ids", []):
            self.revoked.add(str(key_id))
        self.current_epoch = epoch

    def verify_signed_payload(self, key_id: str, payload: dict, signature_b64: str, now: int):
        cert = self.signing_keys.get(key_id)
        if cert is None or key_id in self.revoked:
            return False
        if not (cert.not_before <= int(now) <= cert.not_after):
            return False
        try:
            pub = Ed25519PublicKey.from_public_bytes(b64d(cert.public_key_b64))
            pub.verify(b64d(signature_b64), canonical_json(payload))
            return True
        except Exception:
            return False

class SecureStateCipher:
    """
    AES-256-GCM state encryption.

    The 32-byte key is supplied by a protected keystore/HSM boundary.
    This class deliberately does not generate, persist, escrow, or rotate the KEK.
    """
    @staticmethod
    def encrypt(state: dict, kek: bytes, key_id: str, aad_context: str):
        if len(kek) != 32:
            raise GovernanceError("AES-256-GCM requires a 32-byte key")
        nonce = os.urandom(12)
        aad = canonical_json({"key_id":key_id,"context":aad_context})
        ciphertext = AESGCM(kek).encrypt(nonce, canonical_json(state), aad)
        return {
            "key_id":key_id,
            "context":aad_context,
            "nonce_b64":b64e(nonce),
            "ciphertext_b64":b64e(ciphertext),
        }

    @staticmethod
    def decrypt(blob: dict, kek: bytes):
        if len(kek) != 32:
            raise GovernanceError("AES-256-GCM requires a 32-byte key")
        aad = canonical_json({"key_id":blob["key_id"],"context":blob["context"]})
        plaintext = AESGCM(kek).decrypt(
            b64d(blob["nonce_b64"]), b64d(blob["ciphertext_b64"]), aad
        )
        return json.loads(plaintext.decode("utf-8"))
