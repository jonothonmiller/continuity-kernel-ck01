
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Dict, Optional
import hashlib, json, math
import numpy as np

@dataclass(frozen=True)
class SensorProvenanceRecord:
    entity_id: str
    activity_id: str
    agent_id: str
    source_id: str
    timestamp: str
    measurement_type: str
    value: float | None
    unit: str
    reference_value: float | None
    reference_unit: str | None
    calibration_id: str
    sequence: int
    quality: str
    derived_from: str | None = None

    def canonical_hash(self) -> str:
        raw=json.dumps(asdict(self),sort_keys=True,separators=(",",":")).encode()
        return hashlib.sha256(raw).hexdigest()

class SensorGroundingAdapter:
    """
    Maps physical-sensor observations into explicit provenance records.

    The field structure mirrors the W3C PROV distinction among:
      entity: the measurement record,
      activity: the acquisition/calibration activity,
      agent: the responsible sensor/system.
    """
    def __init__(self, source_id:str, agent_id:str, calibration_id:str):
        self.source_id=source_id
        self.agent_id=agent_id
        self.calibration_id=calibration_id
        self.sequence=0

    def record(self,timestamp,measurement_type,value,unit,
               reference_value=None,reference_unit=None,
               activity_id="sensor_acquisition",derived_from=None):
        self.sequence+=1
        finite=value is not None and np.isfinite(float(value))
        quality="VALID" if finite else "MISSING_OR_INVALID"
        value_out=float(value) if finite else None

        ref_finite=reference_value is not None and np.isfinite(float(reference_value))
        ref_out=float(reference_value) if ref_finite else None

        entity=f"{self.source_id}:{self.sequence}"
        return SensorProvenanceRecord(
            entity_id=entity,activity_id=activity_id,agent_id=self.agent_id,
            source_id=self.source_id,timestamp=str(timestamp),
            measurement_type=str(measurement_type),value=value_out,unit=str(unit),
            reference_value=ref_out,reference_unit=reference_unit,
            calibration_id=self.calibration_id,sequence=self.sequence,
            quality=quality,derived_from=derived_from
        )
